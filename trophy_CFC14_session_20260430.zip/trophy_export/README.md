# CFC14 Trophy Export — April 30, 2026

## What this is
Complete artifact archive from the CFC14 Worker + Extension Sanitizer project.
This conversation reverse-engineered cocodem's dual-C2 malware infrastructure
(111724.xyz + cfc.aroic.workers.dev) and replaced it with a clean local-loop setup.

## What happened in this chat (pre-compaction summary)
See: transcript/2026-04-30-16-19-14-cfc14-worker-extension-integration.txt

## Final architecture
- cfcBase: https://test2.mahnikka.workers.dev/ (YOUR Cloudflare Worker)
- Local proxy: localhost:8520 (Python)
- LM Studio: http://10.0.0.221:1234 (LAN, browser goes direct)
- Zero credential harvesting. Zero phone-home. Everything loops local.

## Files

### outputs/CFC14_FAT_MERGED.js
The final Cloudflare Worker — 984 lines, 218KB.
Replaces BOTH 111724.xyz AND cfc.aroic.workers.dev with one clean worker.
Contains:
  - Full FEATURES_FULL (verbatim live cocodem snapshot, curl 2026-04-29)
  - /api/options with all fields the extension reads
  - /oauth/authorize → sidepanel.html direct redirect (sidepanelToken fix)
  - /oauth/authorize → /oauth/redirect for oauth_callback.html (ERR_BLOCKED fix)
  - /chrome/installed free-trial/launch page
  - /v1/models fallback
  - /health endpoint
  - KV persistence support
  - Config form (div not form, direct input reads — FormData bug fixed)

### uploads/
All files uploaded during the session:
  - CCF2.py        — CFC3_fixed.py (the sanitizer that created the extension)
  - CFC1.py        — Standalone proxy server only
  - CFC2.py        — Earlier sanitizer iteration
  - CFC3.py        — Earlier sanitizer iteration
  - CFC14_worker__5_.js — Intermediate worker version with live FEATURES_FULL
  - request.js     — The ACTUAL request.js from the loaded extension
  - test2_worker_bulletproof_20260427_011757.js — Old worker (April 27)
  - cfc_identity.json — Local proxy identity file (apiBaseUrl: 127.0.0.1:1234/v1)

### transcript/
Pre-compaction conversation summary covering:
  - Worker architecture decisions
  - /api/options field discoveries
  - OAuth flow debugging
  - Bug fixes (form submit, backtick template literals, FormData on div)
  - FEATURES_FULL integration
  - Routing logic (LAN vs internet backends)

## Key bugs found and fixed in this session
1. Form `type="submit"` + no `e.preventDefault()` → page reset on save
   Fix: `<form>` → `<div>`, submit listener → click listener on savebtn

2. `new FormData(divElement)` returns empty → BACKEND_URL always saved as ""
   Fix: Read `elUrl.value`, `elKey.value`, `elLbl.value` directly

3. `oauth_callback.html` ERR_BLOCKED_BY_CLIENT (doesn't exist in fork)
   Fix: Route to /oauth/redirect instead

4. `sidepanelToken` never set (redirect_uri check failed)
   Fix: /oauth/authorize redirects directly to chrome-extension://id/sidepanel.html

5. Missing /api/options fields: apiBaseUrl, apiKey, authToken, identity, backends, blockAnalytics
   Fix: Added all fields based on actual request.js source

6. "request ended without sending any chunks" 
   Root cause: BACKEND_URL not set in worker → extension hits real Anthropic with fake tokens
   Fix: Save BACKEND_URL = http://10.0.0.221:1234 in worker config

## The punchline
Gemma running on a home PC, routed through a sanitized fork of malware 
infrastructure, convinced it's Claude Opus 4.6, following a system prompt 
that says "The assistant is Claude, created by Anthropic."

It worked.
