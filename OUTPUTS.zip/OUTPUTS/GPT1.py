#!/usr/bin/env python3
"""
Standalone CFCBASE server proof.

Scope:
  - Does not edit request.js.
  - Does not edit main.py.
  - Serves the CFCBASE contract on localhost:8520.
  - Uses the existing generated Backend Settings UI when available.
  - Keeps all state in timestamped files next to this script.

Run:
  python OUTPUTS/cfcbase_server_only_20260426_025208.py
"""

import base64
import json
import mimetypes
import os
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from socketserver import TCPServer, ThreadingMixIn
from urllib.parse import parse_qs, urlencode, urlparse


STAMP = "20260426_025208"
EXTENSION_ID = "fcoeoabgfenejglbffodgkkbkcdhcgfn"

SCRIPT_PATH = Path(__file__).resolve()
OUTPUTS_DIR = SCRIPT_PATH.parent
WORKSPACE_DIR = OUTPUTS_DIR.parent

LOCAL_PORT = int(os.environ.get("CFC_LOCAL_PORT", "8520"))
LOCAL_HOST = os.environ.get("CFC_LOCAL_HOST", "localhost")
LOCAL_BASE = f"http://{LOCAL_HOST}:{LOCAL_PORT}/"
LOCAL_BIND = os.environ.get("CFC_BIND_HOST", "127.0.0.1")

REMOTE_BASE = os.environ.get(
    "CFC_REMOTE_BASE",
    "https://myworker.mahnikka.workers.dev/",
).rstrip("/") + "/"

DEFAULT_BACKEND_URL = os.environ.get("CFC_DEFAULT_BACKEND_URL", "http://127.0.0.1:1234/v1")
BACKEND_SETTINGS_URL = LOCAL_BASE + "backend_settings"

STATE_IDENTITY_FILE = OUTPUTS_DIR / f"cfc_identity_{STAMP}.json"
STATE_BACKENDS_FILE = OUTPUTS_DIR / f"cfc_backends_{STAMP}.json"

GENERATED_EXTENSION_DIR = WORKSPACE_DIR / "claude-sanitized-20260425-212051"
GENERATED_ASSETS_DIR = GENERATED_EXTENSION_DIR / "assets"

USER_UUID = "ac507011-00b5-56c4-b3ec-ad820dbafbc1"
ORG_UUID = "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08"


TELEMETRY_DOMAINS = [
    "segment.com",
    "statsig",
    "statsigapi.net",
    "honeycomb",
    "sentry",
    "datadoghq",
    "featureassets",
    "assetsconfigcdn",
    "featuregates",
    "prodregistryv2",
    "beyondwickedmapping",
    "fpjs.dev",
    "openfpcdn.io",
    "api.fpjs.io",
    "googletagmanager",
    "googletag",
]

PROXY_INCLUDES = [
    "https://api.anthropic.com/v1/",
    "cdn.segment.com",
    "featureassets.org",
    "assetsconfigcdn.org",
    "featuregates.org",
    "api.segment.io",
    "prodregistryv2.org",
    "beyondwickedmapping.org",
    "api.honeycomb.io",
    "statsigapi.net",
    "events.statsigapi.net",
    "api.statsigcdn.com",
    "*ingest.us.sentry.io",
    "https://api.anthropic.com/api/oauth/profile",
    "https://api.anthropic.com/api/bootstrap",
    "https://console.anthropic.com/v1/oauth/token",
    "https://platform.claude.com/v1/oauth/token",
    "https://api.anthropic.com/api/oauth/account",
    "https://api.anthropic.com/api/oauth/organizations",
    "https://api.anthropic.com/api/oauth/chat_conversations",
    "/api/web/domain_info/browser_extension",
    "/api/web/url_hash_check/browser_extension",
    "cfc.aroic.workers.dev",
]

DISCARD_INCLUDES = [
    "cdn.segment.com",
    "api.segment.io",
    "events.statsigapi.net",
    "api.honeycomb.io",
    "prodregistryv2.org",
    "*ingest.us.sentry.io",
    "browser-intake-us5-datadoghq.com",
    "fpjs.dev",
    "openfpcdn.io",
    "api.fpjs.io",
    "googletagmanager.com",
]


DEFAULT_IDENTITY = {
    "apiBaseUrl": DEFAULT_BACKEND_URL,
    "apiKey": "",
    "authToken": "",
    "email": "user@local",
    "username": "local-user",
    "licenseKey": "",
    "blockAnalytics": True,
    "modelAliases": {},
    "mode": "",
}

DEFAULT_BACKENDS = [
    {
        "name": "Default",
        "url": DEFAULT_BACKEND_URL,
        "key": "",
        "models": [],
        "modelAlias": {},
        "enabled": True,
    }
]


def read_json_file(path, fallback):
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, type(fallback)):
                return data
        except Exception:
            pass
    return json.loads(json.dumps(fallback))


IDENTITY = read_json_file(STATE_IDENTITY_FILE, DEFAULT_IDENTITY)
BACKENDS = read_json_file(STATE_BACKENDS_FILE, DEFAULT_BACKENDS)


def write_json_file(path, data):
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def jwt(payload):
    header = {"alg": "none", "typ": "JWT"}
    h = base64.urlsafe_b64encode(json.dumps(header).encode("utf-8")).rstrip(b"=").decode("ascii")
    b = base64.urlsafe_b64encode(json.dumps(payload).encode("utf-8")).rstrip(b"=").decode("ascii")
    return h + "." + b + ".local"


def local_token():
    now = int(time.time())
    return {
        "access_token": jwt({"iss": "cfc", "sub": USER_UUID, "exp": now + 315360000, "iat": 1700000000}),
        "token_type": "bearer",
        "expires_in": 315360000,
        "refresh_token": "local-refresh",
        "scope": "user:profile user:inference user:chat",
    }


LOCAL_ACCOUNT = {
    "uuid": USER_UUID,
    "id": USER_UUID,
    "email_address": "user@local",
    "email": "user@local",
    "full_name": "Local User",
    "name": "Local User",
    "display_name": "Local User",
    "has_password": True,
    "has_completed_onboarding": True,
    "preferred_language": "en-US",
    "has_claude_pro": True,
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z",
    "settings": {"theme": "system", "language": "en-US"},
}

LOCAL_ORG = {
    "uuid": ORG_UUID,
    "id": ORG_UUID,
    "name": "Local",
    "role": "admin",
    "organization_type": "personal",
    "billing_type": "self_serve",
    "capabilities": ["chat", "claude_pro_plan", "api", "computer_use", "claude_for_chrome"],
    "rate_limit_tier": "default_claude_pro",
    "settings": {},
    "created_at": "2024-01-01T00:00:00Z",
}


def profile_payload():
    account = dict(LOCAL_ACCOUNT)
    account["email_address"] = IDENTITY.get("email") or "user@local"
    account["email"] = account["email_address"]
    account["full_name"] = IDENTITY.get("username") or "Local User"
    account["name"] = account["full_name"]
    account["display_name"] = account["full_name"]
    return {
        **account,
        "account": account,
        "organization": LOCAL_ORG,
        "memberships": [{"organization": LOCAL_ORG, "role": "admin", "joined_at": "2024-01-01T00:00:00Z"}],
        "active_organization_uuid": ORG_UUID,
    }


def bootstrap_payload():
    prof = profile_payload()
    return {
        **prof,
        "account_uuid": USER_UUID,
        "organizations": [LOCAL_ORG],
        "statsig": {
            "user": {"userID": USER_UUID, "custom": {"organization_uuid": ORG_UUID}},
            "values": {"feature_gates": {}, "dynamic_configs": {}, "layer_configs": {}},
        },
        "flags": {},
        "features": [],
        "active_flags": {},
        "active_subscription": {
            "plan": "claude_pro",
            "status": "active",
            "type": "claude_pro",
            "billing_period": "monthly",
            "current_period_start": "2024-01-01T00:00:00Z",
            "current_period_end": "2099-12-31T23:59:59Z",
        },
        "has_claude_pro": True,
        "chat_enabled": True,
        "capabilities": ["chat", "claude_pro_plan", "api", "computer_use", "claude_for_chrome"],
        "rate_limit_tier": "default_claude_pro",
        "settings": {"theme": "system", "language": "en-US"},
    }


def merged_model_aliases():
    out = {}
    aliases = IDENTITY.get("modelAliases") or {}
    if isinstance(aliases, dict):
        out.update(aliases)
    for backend in BACKENDS:
        backend_alias = backend.get("modelAlias") or {}
        if backend.get("enabled", True) and isinstance(backend_alias, dict):
            out.update(backend_alias)
    return out


def safe_ui_nodes():
    link = {
        "type": "a",
        "props": {
            "href": BACKEND_SETTINGS_URL,
            "target": "_blank",
            "rel": "noreferrer",
            "children": "Backend Settings",
        },
    }
    labels = [
        "API Key",
        "Api Key",
        "Enter API Key",
        "License Key",
        "Manage API key",
        "Set API key",
        "Configure API",
        "Login",
        "Log in",
        "Sign in",
    ]
    nodes = []
    for label in labels:
        nodes.append({"selector": {"type": "button", "props": {"children": label}}, "replace": link})
        nodes.append({"selector": {"type": "a", "props": {"children": label}}, "replace": link})
    return nodes


def options_payload():
    discard = list(DISCARD_INCLUDES) if IDENTITY.get("blockAnalytics", True) else []
    return {
        "mode": IDENTITY.get("mode", "") or "",
        "cfcBase": LOCAL_BASE,
        "remoteCfcBase": REMOTE_BASE,
        "anthropicBaseUrl": "",
        "apiBaseUrl": IDENTITY.get("apiBaseUrl") or DEFAULT_BACKEND_URL,
        "apiKey": IDENTITY.get("apiKey", ""),
        "authToken": IDENTITY.get("authToken", ""),
        "identity": {
            "email": IDENTITY.get("email", "user@local"),
            "username": IDENTITY.get("username", "local-user"),
            "licenseKey": IDENTITY.get("licenseKey", ""),
        },
        "backends": BACKENDS,
        "apiBaseIncludes": [],
        "proxyIncludes": list(PROXY_INCLUDES),
        "discardIncludes": discard,
        "modelAlias": merged_model_aliases(),
        "ui": {
            "/options.html": {
                "backend_settings_link": {
                    "selector": "#root",
                    "html": (
                        "<div style='font-family:-apple-system,sans-serif;padding:24px'>"
                        "<h1>Backend Settings</h1>"
                        "<p>CFCBASE is serving the safe API/backend configuration endpoint.</p>"
                        f"<p><a href='{BACKEND_SETTINGS_URL}' target='_blank' rel='noreferrer'>"
                        "Open Backend Settings</a></p></div>"
                    ),
                }
            }
        },
        "uiNodes": safe_ui_nodes(),
        "blockAnalytics": bool(IDENTITY.get("blockAnalytics", True)),
    }


def auth_payload(path):
    if "/licenses/verify" in path:
        return {"valid": True, "license": "local", "tier": "pro", "expires": "2099-12-31"}
    if "/mcp/v2/bootstrap" in path:
        return {"servers": [], "tools": [], "enabled": False}
    if "/spotlight" in path:
        return {"items": [], "total": 0}
    if "/features/" in path:
        return {"enabled": True, "features": {}}
    if "/oauth/account/settings" in path:
        return {"settings": {"theme": "system", "language": "en-US"}}
    if "/oauth/profile" in path:
        return profile_payload()
    if "/oauth/account" in path:
        return profile_payload()
    if "/oauth/token" in path:
        return local_token()
    if "/bootstrap" in path:
        return bootstrap_payload()
    if "/oauth/organizations" in path:
        tail = path.split("/oauth/organizations/", 1)[1] if "/oauth/organizations/" in path else ""
        if "/" in tail:
            return {}
        if tail:
            return LOCAL_ORG
        return [LOCAL_ORG]
    if "/chat_conversations" in path:
        return {"conversations": [], "limit": 0, "has_more": False, "cursor": None}
    if "/domain_info" in path:
        return {"domain": "local", "allowed": True}
    if "/url_hash_check" in path:
        return {"allowed": True}
    if "/usage" in path:
        return {"usage": {}, "limit": None}
    if "/entitlements" in path:
        return {"entitlements": []}
    if "/flags" in path:
        return {}
    return {}


def pick_backends(model):
    enabled = [b for b in BACKENDS if b.get("enabled", True)]
    exact = [b for b in enabled if b.get("models") and model in b.get("models", [])]
    catch_all = [b for b in enabled if not b.get("models")]
    preferred = exact or catch_all or enabled
    if not preferred:
        return []
    first = preferred[0]
    rest = [b for b in enabled if b is not first]
    return [first] + rest


def html_page(title, body):
    return (
        "<!doctype html><html><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<title>{title}</title>"
        "<style>body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;"
        "background:#f9f8f3;color:#2f2a1f;margin:0;padding:32px}"
        ".box{max-width:760px;margin:0 auto;background:white;border:1px solid #e5e2d9;"
        "border-radius:18px;padding:28px;box-shadow:0 10px 30px rgba(0,0,0,.04)}"
        "a,.btn{display:inline-flex;align-items:center;height:40px;padding:0 16px;"
        "background:#c45f3d;color:white;text-decoration:none;border-radius:10px;"
        "font-weight:700;border:0;cursor:pointer}code{background:#f4f1ea;padding:2px 5px;"
        "border-radius:5px}</style></head><body><div class='box'>"
        f"{body}</div></body></html>"
    )


def root_html():
    body = (
        "<h1>CFCBASE Server</h1>"
        f"<p>Local base: <code>{LOCAL_BASE}</code></p>"
        f"<p>Remote base: <code>{REMOTE_BASE}</code></p>"
        "<p>This standalone server exposes the CFC route contract without editing request.js.</p>"
        f"<p><a href='{BACKEND_SETTINGS_URL}'>Backend Settings</a></p>"
        "<ul>"
        "<li><code>/api/options</code></li>"
        "<li><code>/api/identity</code></li>"
        "<li><code>/api/backends</code></li>"
        "<li><code>/oauth/authorize</code> and <code>/oauth/redirect</code></li>"
        "<li><code>/v1/*</code> backend proxy</li>"
        "</ul>"
    )
    return html_page("CFCBASE Server", body)


def backend_settings_html():
    body = (
        "<h1>Backend Settings</h1>"
        "<p>The proxy is the source of truth for API base URL, API key, auth token, model aliases, identity, and telemetry blocking.</p>"
        "<form method='post' action='/api/identity_form'>"
        f"<p><label>API Base URL<br><input name='apiBaseUrl' value='{IDENTITY.get('apiBaseUrl') or DEFAULT_BACKEND_URL}' style='width:100%;height:36px'></label></p>"
        f"<p><label>API Key<br><input name='apiKey' value='{IDENTITY.get('apiKey','')}' style='width:100%;height:36px'></label></p>"
        f"<p><label>Auth Token<br><input name='authToken' value='{IDENTITY.get('authToken','')}' style='width:100%;height:36px'></label></p>"
        f"<p><label>Email<br><input name='email' value='{IDENTITY.get('email','user@local')}' style='width:100%;height:36px'></label></p>"
        f"<p><label>Username<br><input name='username' value='{IDENTITY.get('username','local-user')}' style='width:100%;height:36px'></label></p>"
        f"<p><label>License Key<br><input name='licenseKey' value='{IDENTITY.get('licenseKey','')}' style='width:100%;height:36px'></label></p>"
        "<p><label><input type='checkbox' name='blockAnalytics' checked> Block analytics/telemetry</label></p>"
        "<p><button class='btn' type='submit'>Save Settings</button></p>"
        "</form>"
        "<p>JSON endpoints are also available at <code>/api/identity</code> and <code>/api/backends</code>.</p>"
    )
    return html_page("Backend Settings", body)


def authorize_html(query):
    params = parse_qs(query, keep_blank_values=True)
    hidden = "".join(
        f"<input type='hidden' name='{k}' value='{v[0] if v else ''}'>"
        for k, v in params.items()
    )
    body = (
        "<h1>Local CFC Sign In</h1>"
        "<p>No real login is required for this local malware-removal test server.</p>"
        "<form method='get' action='/oauth/redirect'>"
        f"{hidden}"
        "<button class='btn' type='submit'>Skip / Enter</button>"
        "</form>"
    )
    return html_page("Local CFC Sign In", body)


def redirect_html(query):
    params = parse_qs(query, keep_blank_values=True)
    redirect_uri = params.get("redirect_uri", [""])[0]
    state = params.get("state", [""])[0]
    code = params.get("code", [f"cfc-local-{int(time.time())}"])[0]
    final_uri = redirect_uri
    if final_uri:
        joiner = "&" if "?" in final_uri else "?"
        final_uri = final_uri + joiner + urlencode({"code": code, "state": state})
    body = (
        "<h1>Signed in locally</h1>"
        "<p>The CFCBASE server issued a local test code. No remote credentials were requested.</p>"
        f"<p><code>{final_uri or code}</code></p>"
        "<p>You can close this tab.</p>"
    )
    return html_page("Local Redirect", body)


class Handler(BaseHTTPRequestHandler):
    server_version = "CFCBASE/20260426_025208"

    def log_message(self, fmt, *args):
        print(f"[{time.strftime('%H:%M:%S')}] {self.command} {self.path} - " + (fmt % args))

    def cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
        self.send_header(
            "Access-Control-Allow-Headers",
            "Content-Type, Cache-Control, Accept, Authorization, x-api-key, "
            "anthropic-version, anthropic-beta, anthropic-client-platform, "
            "anthropic-client-version, x-app, x-service-name",
        )
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "86400")

    def send_bytes(self, data, content_type="application/octet-stream", status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Connection", "close")
        self.cors()
        self.end_headers()
        try:
            self.wfile.write(data)
        except OSError:
            pass

    def send_json(self, data, status=200):
        self.send_bytes(json.dumps(data).encode("utf-8"), "application/json", status)

    def send_html(self, html, status=200):
        self.send_bytes(html.encode("utf-8"), "text/html; charset=utf-8", status)

    def send_204(self):
        self.send_response(204)
        self.send_header("Connection", "close")
        self.cors()
        self.end_headers()

    def is_telemetry(self, path):
        return any(domain in path for domain in TELEMETRY_DOMAINS)

    def is_v1(self, path):
        if "/v1/oauth" in path:
            return False
        return path.startswith("/v1/") or (
            "/v1/" in path and ("api.anthropic.com" in path or path.startswith("/https://api.anthropic.com/"))
        )

    def is_auth(self, path):
        if path.startswith("/https://") or path.startswith("/http://") or path.startswith("/chrome-extension://"):
            return True
        markers = [
            "/oauth/",
            "/bootstrap",
            "/domain_info",
            "/chat_conversations",
            "/organizations",
            "/url_hash_check",
            "/api/web/",
            "/features/",
            "/spotlight",
            "/usage",
            "/entitlements",
            "/flags",
            "/mcp/v2/",
            "/licenses/",
        ]
        return any(marker in path for marker in markers)

    def serve_static(self, path):
        rel = path.lstrip("/").split("?", 1)[0]
        candidates = []
        if rel == "assets/backend_settings_ui.js":
            candidates.append(GENERATED_ASSETS_DIR / "backend_settings_ui.js")
        if rel.startswith("assets/"):
            candidates.append(GENERATED_ASSETS_DIR / rel[len("assets/"):])
        candidates.append(GENERATED_EXTENSION_DIR / rel)
        for candidate in candidates:
            if candidate.exists() and candidate.is_file():
                content_type = mimetypes.guess_type(str(candidate))[0] or "application/octet-stream"
                if candidate.suffix == ".js":
                    content_type = "application/javascript; charset=utf-8"
                if candidate.suffix == ".css":
                    content_type = "text/css; charset=utf-8"
                self.send_bytes(candidate.read_bytes(), content_type)
                return True
        return False

    def v1_suffix(self, path):
        if path.startswith("/v1/"):
            return path[3:]
        idx = path.find("/v1/")
        if idx >= 0:
            return path[idx + 3:]
        return path

    def read_body(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        return self.rfile.read(length) if length else b""

    def forward_v1(self, method, body):
        model = ""
        if body:
            try:
                model = json.loads(body.decode("utf-8")).get("model", "")
            except Exception:
                model = ""
        suffix = self.v1_suffix(self.path)
        last_error = None
        allowed_headers = {
            "content-type",
            "accept",
            "authorization",
            "anthropic-version",
            "anthropic-beta",
            "anthropic-client-platform",
            "anthropic-client-version",
            "x-api-key",
            "x-service-name",
        }
        base_headers = {k: v for k, v in self.headers.items() if k.lower() in allowed_headers}
        for backend in pick_backends(model):
            target = backend.get("url", DEFAULT_BACKEND_URL).rstrip("/") + suffix
            headers = dict(base_headers)
            if backend.get("key"):
                headers["Authorization"] = "Bearer " + backend["key"]
            elif IDENTITY.get("apiKey"):
                headers["Authorization"] = "Bearer " + IDENTITY["apiKey"]
            send_body = body
            if send_body and method in ("POST", "PUT", "PATCH"):
                try:
                    parsed = json.loads(send_body.decode("utf-8"))
                    aliases = {**merged_model_aliases(), **(backend.get("modelAlias") or {})}
                    if parsed.get("model") in aliases:
                        parsed["model"] = aliases[parsed["model"]]
                        send_body = json.dumps(parsed).encode("utf-8")
                except Exception:
                    pass
            try:
                request = urllib.request.Request(target, data=send_body or None, headers=headers, method=method)
                response = urllib.request.urlopen(request, timeout=300)
                data = response.read()
                content_type = response.headers.get("Content-Type") or "application/json"
                self.send_bytes(data, content_type, response.status)
                return
            except urllib.error.HTTPError as exc:
                data = exc.read() or b""
                if exc.code < 500:
                    self.send_bytes(data, exc.headers.get("Content-Type") or "application/json", exc.code)
                    return
                last_error = f"HTTP {exc.code}"
            except Exception as exc:
                last_error = str(exc)
        self.send_json({"error": {"type": "proxy_error", "message": "All backends failed. Last: " + str(last_error)}}, 502)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Connection", "close")
        self.cors()
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if self.is_telemetry(self.path):
            self.send_204()
            return
        if self.serve_static(path):
            return
        if self.is_v1(self.path):
            self.forward_v1("GET", b"")
            return
        if path == "/" or path == "":
            self.send_html(root_html())
            return
        if path.startswith("/api/options"):
            self.send_json(options_payload())
            return
        if path.startswith("/api/identity"):
            self.send_json(IDENTITY)
            return
        if path.startswith("/api/backends"):
            self.send_json({"backends": BACKENDS})
            return
        if path.startswith("/api/arc-split-view"):
            self.send_json({"html": "<div id='cfc-arc'>Local CFC arc split view</div>"})
            return
        if path.startswith("/discard"):
            self.send_204()
            return
        if path.startswith("/backend_settings"):
            self.send_html(backend_settings_html())
            return
        if path.startswith("/oauth/authorize"):
            self.send_html(authorize_html(parsed.query))
            return
        if path.startswith("/oauth/redirect"):
            self.send_html(redirect_html(parsed.query))
            return
        if self.is_auth(self.path):
            self.send_json(auth_payload(self.path))
            return
        self.send_html(html_page("CFCBASE Route", f"<h1>CFCBASE Route</h1><p><code>{self.path}</code></p>"))

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        body = self.read_body()
        if self.is_telemetry(self.path):
            self.send_204()
            return
        if path.startswith("/api/identity"):
            try:
                data = json.loads(body.decode("utf-8") or "{}")
                for key in ["apiBaseUrl", "apiKey", "authToken", "email", "username", "licenseKey", "blockAnalytics", "modelAliases", "mode"]:
                    if key in data:
                        IDENTITY[key] = data[key]
                if not isinstance(IDENTITY.get("modelAliases"), dict):
                    IDENTITY["modelAliases"] = {}
                write_json_file(STATE_IDENTITY_FILE, IDENTITY)
                self.send_json({"ok": True, "identity": IDENTITY})
            except Exception as exc:
                self.send_json({"ok": False, "error": str(exc)}, 400)
            return
        if path.startswith("/api/identity_form"):
            form = parse_qs(body.decode("utf-8"), keep_blank_values=True)
            for key in ["apiBaseUrl", "apiKey", "authToken", "email", "username", "licenseKey"]:
                if key in form:
                    IDENTITY[key] = form[key][0]
            IDENTITY["blockAnalytics"] = "blockAnalytics" in form
            write_json_file(STATE_IDENTITY_FILE, IDENTITY)
            self.send_html(backend_settings_html())
            return
        if path.startswith("/api/backends"):
            try:
                data = json.loads(body.decode("utf-8") or "{}")
                backends = data.get("backends")
                if not isinstance(backends, list) or not backends:
                    raise ValueError("backends must be a non-empty list")
                for backend in backends:
                    backend.setdefault("name", "")
                    backend.setdefault("url", DEFAULT_BACKEND_URL)
                    backend.setdefault("key", "")
                    backend.setdefault("models", [])
                    backend.setdefault("modelAlias", {})
                    backend.setdefault("enabled", True)
                BACKENDS[:] = backends
                write_json_file(STATE_BACKENDS_FILE, BACKENDS)
                self.send_json({"ok": True, "backends": BACKENDS})
            except Exception as exc:
                self.send_json({"ok": False, "error": str(exc)}, 400)
            return
        if self.is_v1(self.path):
            self.forward_v1("POST", body)
            return
        if self.is_auth(self.path):
            self.send_json(auth_payload(self.path))
            return
        self.send_json({"ok": True})

    def do_PUT(self):
        body = self.read_body()
        if self.is_v1(self.path):
            self.forward_v1("PUT", body)
            return
        if self.is_auth(self.path):
            self.send_json(auth_payload(self.path))
            return
        self.send_json({"ok": True})

    def do_PATCH(self):
        body = self.read_body()
        if self.is_v1(self.path):
            self.forward_v1("PATCH", body)
            return
        if self.is_auth(self.path):
            self.send_json(auth_payload(self.path))
            return
        self.send_json({"ok": True})

    def do_DELETE(self):
        body = self.read_body()
        if self.is_v1(self.path):
            self.forward_v1("DELETE", body)
            return
        if self.is_auth(self.path):
            self.send_json(auth_payload(self.path))
            return
        self.send_json({"ok": True})


class Server(ThreadingMixIn, TCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    print("=" * 72)
    print("Standalone CFCBASE server")
    print("=" * 72)
    print("Local:  " + LOCAL_BASE)
    print("Remote: " + REMOTE_BASE)
    print("Options: " + LOCAL_BASE + "api/options")
    print("Backend Settings: " + BACKEND_SETTINGS_URL)
    print("Identity state file: " + str(STATE_IDENTITY_FILE))
    print("Backends state file: " + str(STATE_BACKENDS_FILE))
    print()
    with Server((LOCAL_BIND, LOCAL_PORT), Handler) as server:
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        print("Server running. Press Ctrl+C to stop.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("Stopping server.")
            server.shutdown()


if __name__ == "__main__":
    main()
