#!/usr/bin/env python3
# ============================================================================
# CFCBASE flat standalone server -- NO WRAPPERS, NO importlib.
#
# Source of truth for behavior: 12 - Copy.py  (the user-confirmed correct
# implementation for ui-node behavior).  All wrappers and re-exec chains
# (cfcbase_server_proxy_pages_from_12py_*.py, *_api_key_only_*.py,
# *_12py_empty_ui_*.py, *_12py_options_payload_empty_ui_*.py,
# *_existing_backend_settings_loader_*.py) are collapsed into this single
# file.
#
# Inlined from 12 - Copy.py (lines 1111-1604):
#   BACKENDS / _load_backends / _save_backends / _pick_backends
#   LOCAL_PROFILE / LOCAL_BOOTSTRAP / LOCAL_ORGS / LOCAL_CONV
#   _jwt / build_local_token
#   get_local_auth
#   _redirect_page_html
#   _build_proxy_settings_html  (the dark Cocodem-styled multi-backend UI
#                                from pic 1, served at /backend_settings)
#   MultiC2Handler (do_OPTIONS, do_GET, do_POST, do_PATCH,
#                   _forward_v1, _is_v1, _is_auth, _cors,
#                   _json, _html, _204)
#   MultiC2Server / start_multi_c2 / main
#
# Differences from 12.py:
#   1. No sanitizer steps (no copy_source / patch_manifest / etc.).  This
#      file ONLY runs the proxy.  Use 12.py once to produce the sanitized
#      claude-sanitized-* extension folder; then run this file standalone
#      whenever you want the proxy without re-running the sanitizer.
#   2. /v1/profile, /v1/account, /v1/auth* are EXCLUDED from _is_v1 and
#      INCLUDED in _is_auth, so when ANTHROPIC_BASE_URL is set to the proxy
#      (http://localhost:8520/v1) instead of LM Studio directly, those
#      paths are answered locally with LOCAL_PROFILE.  This eliminates the
#      404s shown in pic 3 (request.js:251).  See "FIX 1" comments below.
#   3. OUTPUT_DIR for serving /assets/backend_settings_ui.js auto-detects
#      the newest claude-sanitized-* directory in the current working
#      directory, or honors $CFC_EXT_DIR if set.  No re-sanitization.
#   4. /api/options response is verbatim 12.py's contract:
#         "modelAlias": {}, "ui": {}, "uiNodes": []
#      so the server NEVER replaces extension UI nodes.  The Backend
#      Settings link in /options.html is injected by request.js itself
#      (MutationObserver on the "Log out" entry) -- NOT by uiNodes.
#      This is the fix for pic 4 (where Microphone / Permissions / nav
#      entries were getting clobbered by the older safe_ui_nodes lists).
#
# Configuration (all optional environment variables):
#   CFC_PORT             default 8520
#   CFC_DEFAULT_BACKEND  default http://127.0.0.1:1234/v1
#   CFC_EXT_DIR          default auto-detect newest claude-sanitized-*
#   CFC_BACKENDS_FILE    default ./cfc_backends.json
#   CFC_BIND             default 127.0.0.1
#
# Run:
#   python cfcbase_server_flat_no_wrappers_20260426_190246.py
#
# To eliminate the /profile 404s from request.js:
#   In pic 2's Backend Settings, set
#     API Base URL (ANTHROPIC_BASE_URL) = http://localhost:8520/v1
#   so /v1/profile traffic flows through this proxy (where it is
#   intercepted) instead of going straight to LM Studio.
# ============================================================================

import base64
import json
import os
import socketserver
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse


# ---------- constants -------------------------------------------------------

EXTENSION_ID = "fcoeoabgfenejglbffodgkkbkcdhcgfn"
CFC_PORT = int(os.environ.get("CFC_PORT", "8520"))
CFC_BIND = os.environ.get("CFC_BIND", "127.0.0.1")
CFC_BASE = f"http://localhost:{CFC_PORT}/"
DEFAULT_BACKEND_URL = os.environ.get(
    "CFC_DEFAULT_BACKEND", "http://127.0.0.1:1234/v1"
)
BACKEND_SETTINGS_URL = f"http://localhost:{CFC_PORT}/backend_settings"
BACKENDS_FILE = Path(os.environ.get("CFC_BACKENDS_FILE", "cfc_backends.json"))
SCRIPT_PATH = Path(__file__).resolve()
SCRIPT_DIR = SCRIPT_PATH.parent


def _resolve_output_dir():
    """Find the sanitized extension directory for serving /assets/*."""
    env = os.environ.get("CFC_EXT_DIR")
    if env:
        p = Path(env)
        if p.is_dir():
            return p
    # Search a few likely roots: cwd, script dir, and one level up.
    for root in (Path.cwd(), SCRIPT_DIR, SCRIPT_DIR.parent):
        try:
            cands = [
                c for c in root.glob("claude-sanitized-*") if c.is_dir()
            ]
        except OSError:
            continue
        if cands:
            cands.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            return cands[0]
    # Fallback: use cwd; serve_static will just 204 if the file is missing.
    return Path.cwd()


OUTPUT_DIR = _resolve_output_dir()


# ---------- backends store --------------------------------------------------

def _load_backends():
    if BACKENDS_FILE.exists():
        try:
            d = json.loads(BACKENDS_FILE.read_text(encoding="utf-8"))
            if isinstance(d, list) and d:
                return d
        except Exception:
            pass
    return [
        {"name": "Default", "models": [], "url": DEFAULT_BACKEND_URL, "key": ""}
    ]


def _save_backends():
    BACKENDS_FILE.write_text(
        json.dumps(BACKENDS, indent=2), encoding="utf-8"
    )


BACKENDS = _load_backends()


def _pick_backends(model):
    # First backend whose models list contains the requested model wins.
    # Empty models list = catch-all (must be last).
    preferred = next(
        (b for b in BACKENDS if b.get("models") and model in b["models"]),
        next(
            (b for b in BACKENDS if not b.get("models")),
            BACKENDS[-1] if BACKENDS else None,
        ),
    )
    if preferred is None:
        return []
    return [preferred] + [b for b in BACKENDS if b is not preferred]


# ---------- local profile / bootstrap / org payloads (verbatim 12.py) -------

LOCAL_PROFILE = {
    "account": {
        "uuid": "ac507011-00b5-56c4-b3ec-ad820dbafbc1",
        "email_address": "free@claudeagent.ai",
        "email": "free@claudeagent.ai",
        "full_name": "Local User",
        "name": "Local User",
        "display_name": "Local User",
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z",
        "id": "ac507011-00b5-56c4-b3ec-ad820dbafbc1",
        "has_password": True,
        "has_completed_onboarding": True,
        "preferred_language": "en-US",
        "has_claude_pro": True,
    },
    "organization": {
        "uuid": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
        "id": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
        "name": "Local",
        "role": "admin",
        "organization_type": "personal",
        "billing_type": "self_serve",
        "created_at": "2024-01-01T00:00:00Z",
    },
    "memberships": [
        {
            "organization": {
                "uuid": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
                "id": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
                "name": "Local",
                "organization_type": "personal",
                "billing_type": "self_serve",
            },
            "role": "admin",
            "joined_at": "2024-01-01T00:00:00Z",
        }
    ],
    "uuid": "ac507011-00b5-56c4-b3ec-ad820dbafbc1",
    "id": "ac507011-00b5-56c4-b3ec-ad820dbafbc1",
    "email": "free@claudeagent.ai",
    "email_address": "free@claudeagent.ai",
    "full_name": "Local User",
    "name": "Local User",
    "display_name": "Local User",
    "has_password": True,
    "has_completed_onboarding": True,
    "preferred_language": "en-US",
    "active_organization_uuid": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
    "settings": {"theme": "system", "language": "en-US"},
}


def _jwt(payload):
    h = base64.b64encode(
        json.dumps({"alg": "none", "typ": "JWT"}).encode()
    ).decode()
    b = base64.b64encode(json.dumps(payload).encode()).decode()
    return f"{h}.{b}.local"


def build_local_token():
    now = int(time.time())
    p = {
        "iss": "cfc",
        "sub": "ac507011-00b5-56c4-b3ec-ad820dbafbc1",
        "exp": now + 315360000,
        "iat": now,
    }
    return {
        "access_token": _jwt(p),
        "token_type": "bearer",
        "expires_in": 315360000,
        "refresh_token": _jwt(p),
        "scope": "user:profile user:inference user:chat",
    }


LOCAL_BOOTSTRAP = {
    "account": {
        "uuid": "ac507011-00b5-56c4-b3ec-ad820dbafbc1",
        "id": "ac507011-00b5-56c4-b3ec-ad820dbafbc1",
        "email": "free@claudeagent.ai",
        "email_address": "free@claudeagent.ai",
        "full_name": "Local User",
        "name": "Local User",
        "display_name": "Local User",
        "has_password": True,
        "has_completed_onboarding": True,
        "preferred_language": "en-US",
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z",
        "settings": {"theme": "system", "language": "en-US"},
    },
    "uuid": "ac507011-00b5-56c4-b3ec-ad820dbafbc1",
    "id": "ac507011-00b5-56c4-b3ec-ad820dbafbc1",
    "account_uuid": "ac507011-00b5-56c4-b3ec-ad820dbafbc1",
    "email": "free@claudeagent.ai",
    "email_address": "free@claudeagent.ai",
    "full_name": "Local User",
    "name": "Local User",
    "display_name": "Local User",
    "has_password": True,
    "has_completed_onboarding": True,
    "preferred_language": "en-US",
    "active_organization_uuid": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
    "organization": {
        "uuid": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
        "id": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
        "name": "Local",
        "role": "admin",
        "organization_type": "personal",
        "billing_type": "self_serve",
        "capabilities": [
            "chat",
            "claude_pro_plan",
            "api",
            "computer_use",
            "claude_for_chrome",
        ],
        "rate_limit_tier": "default_claude_pro",
        "settings": {},
    },
    "organizations": [
        {
            "uuid": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
            "id": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
            "name": "Local",
            "role": "admin",
            "organization_type": "personal",
            "billing_type": "self_serve",
            "capabilities": ["chat", "claude_pro_plan", "api"],
            "rate_limit_tier": "default_claude_pro",
        }
    ],
    "memberships": [
        {
            "organization": {
                "uuid": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
                "id": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
                "name": "Local",
                "organization_type": "personal",
                "billing_type": "self_serve",
                "capabilities": ["chat", "api"],
                "rate_limit_tier": "default_claude_pro",
            },
            "role": "admin",
            "joined_at": "2024-01-01T00:00:00Z",
        }
    ],
    "statsig": {
        "user": {
            "userID": "ac507011-00b5-56c4-b3ec-ad820dbafbc1",
            "custom": {
                "organization_uuid": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08"
            },
        },
        "values": {
            "feature_gates": {},
            "dynamic_configs": {},
            "layer_configs": {},
        },
    },
    "flags": {},
    "features": [],
    "active_flags": {},
    "active_subscription": {
        "plan": "claude_pro",
        "status": "active",
        "type": "claude_pro",
        "billing_period": "monthly",
        "current_period_start": "2024-01-01T00:00:00Z",
        "current_period_end": "2099-12-31T23:59:59Z",
    },
    "has_claude_pro": True,
    "chat_enabled": True,
    "capabilities": [
        "chat",
        "claude_pro_plan",
        "api",
        "computer_use",
        "claude_for_chrome",
    ],
    "rate_limit_tier": "default_claude_pro",
    "settings": {"theme": "system", "language": "en-US"},
}


LOCAL_ORGS = [
    {
        "uuid": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
        "id": "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08",
        "name": "Local",
        "role": "admin",
        "organization_type": "personal",
        "billing_type": "self_serve",
        "capabilities": ["chat", "claude_pro_plan", "api"],
        "rate_limit_tier": "default_claude_pro",
        "settings": {},
        "created_at": "2024-01-01T00:00:00Z",
    }
]


LOCAL_CONV = {"conversations": [], "limit": 0, "has_more": False, "cursor": None}


def get_local_auth(path):
    # Order matters -- more specific markers first.
    if "/mcp/v2/bootstrap" in path:
        return {"servers": [], "tools": [], "enabled": False}
    if "/spotlight" in path:
        return {"items": [], "total": 0}
    if "/features/" in path:
        return {"enabled": True, "features": {}}
    if "/oauth/account/settings" in path:
        return {"settings": {"theme": "system", "language": "en-US"}}
    if "/oauth/profile" in path:
        return LOCAL_PROFILE
    if "/oauth/account" in path:
        return LOCAL_PROFILE
    if "/oauth/token" in path:
        return build_local_token()
    if "/bootstrap" in path:
        return LOCAL_BOOTSTRAP
    if "/oauth/organizations" in path:
        tail = (
            path.split("/oauth/organizations/", 1)[1]
            if "/oauth/organizations/" in path
            else ""
        )
        if "/" in tail:
            return {}
        if tail:
            return LOCAL_ORGS[0] if LOCAL_ORGS else {}
        return LOCAL_ORGS
    if "/chat_conversations" in path:
        return LOCAL_CONV
    if "/domain_info" in path:
        return {"domain": "local", "allowed": True}
    if "/url_hash_check" in path:
        return {"allowed": True}
    if "/usage" in path:
        return {"usage": {}, "limit": None}
    if "/entitlements" in path:
        return {"entitlements": []}
    if "/flags" in path:
        return {}
    # FIX 1 -- catch bare /profile, /v1/profile, /account, /v1/account,
    # /auth/profile from request.js when ANTHROPIC_BASE_URL is the proxy.
    if "/profile" in path:
        return LOCAL_PROFILE
    if "/account" in path:
        return LOCAL_PROFILE
    if "/auth" in path:
        return LOCAL_PROFILE
    return {}


# ---------- HTML pages (verbatim 12.py) -------------------------------------

def _redirect_page_html():
    eid = EXTENSION_ID
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Authenticating...</title></head>
<body style="background:#f9f8f3;font-family:-apple-system,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
<div style="background:white;border:1px solid #e5e2d9;border-radius:32px;padding:40px;max-width:400px;width:100%;text-align:center">
  <h2 style="margin:0 0 8px;font-size:22px;font-family:'Iowan Old Style',Georgia,serif;font-weight:400;color:#1d1b16">Signed in!</h2>
  <p id="msg" style="color:#8b856c;font-size:13px;font-weight:500;margin:8px 0">Working&hellip;</p>
</div>
<script>
(async()=>{{
  const msg=document.getElementById("msg");
  const done=t=>{{msg.textContent=t;msg.style.color="#2d6a4f";setTimeout(()=>{{try{{window.close()}}catch(e){{}}}},800)}};
  try{{
    const p=new URLSearchParams(window.location.search);
    const r=p.get("redirect_uri")||"",state=p.get("state")||"";
    let eid="{eid}";
    if(r.startsWith("chrome-extension://")){{try{{eid=new URL(r).host}}catch(e){{}}}}
    const arr=new Uint8Array(32);crypto.getRandomValues(arr);
    const code="cfc-"+btoa(String.fromCharCode(...arr))
      .replace(/\\+/g,"-").replace(/\\//g,"_").replace(/=/g,"");
    let final=r;
    if(final){{try{{const u=new URL(final);u.searchParams.set("code",code);
      if(state)u.searchParams.set("state",state);final=u.toString();}}
      catch(e){{final=r+(r.includes("?")?"&":"?")+"code="+code}}}}
    if(typeof chrome!=="undefined"&&chrome.runtime&&eid){{
      chrome.runtime.sendMessage(eid,{{type:"oauth_redirect",redirect_uri:final}},rv=>{{
        if(chrome.runtime.lastError||!rv?.success){{
          chrome.runtime.sendMessage(eid,{{type:"_set_storage_local",data:{{
            accessToken:btoa(JSON.stringify({{alg:"none",typ:"JWT"}}))+"."+
              btoa(JSON.stringify({{iss:"cfc",sub:"ac507011-00b5-56c4-b3ec-ad820dbafbc1",exp:9999999999,
                iat:Math.floor(Date.now()/1000)}}))+".local",
            refreshToken:"local-refresh",tokenExpiry:Date.now()+31536000000,
            accountUuid:"ac507011-00b5-56c4-b3ec-ad820dbafbc1",
            sidepanelToken:"cfc-local",sidepanelTokenExpiry:Date.now()+31536000000,
          }}}},()=>done("Done!"));
        }}else done("Done!");
      }});
    }}else done("Auth complete.");
  }}catch(e){{msg.textContent="Error: "+e.message;msg.style.color="#b04a3d"}}
}})();
</script></body></html>"""


def _build_proxy_settings_html():
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Backend Settings</title>
<style>
*{{box-sizing:border-box}}
body{{font-family:-apple-system,sans-serif;background:#f9f8f3;color:#3d3929;
margin:0;padding:32px 20px;min-height:100vh}}
.w{{background:white;border:1px solid #e5e2d9;max-width:660px;margin:0 auto;padding:36px;
border-radius:24px;box-shadow:0 8px 32px rgba(0,0,0,.04)}}
h1{{font-size:24px;font-family:"Iowan Old Style",Georgia,serif;color:#1d1b16;
font-weight:400;letter-spacing:-.02em;margin:0 0 8px}}
.sub{{color:#6b6651;font-size:13px;margin:0 0 24px}}
.backend{{border:1px solid #e5e2d9;border-radius:12px;padding:18px;
margin-bottom:12px;background:#fcfbf9;position:relative}}
.bhead{{display:flex;align-items:center;gap:8px;margin-bottom:14px}}
.bname{{font-weight:700;font-size:14px;flex:1;color:#1d1b16}}
.badge{{font-size:10px;background:#e5e2d9;color:#6b6651;padding:2px 7px;
border-radius:4px;font-weight:700;letter-spacing:.05em}}
.row{{display:grid;grid-template-columns:1fr 1fr;gap:12px}}
label{{display:block;font-size:9px;font-weight:900;color:#8B856C;text-transform:uppercase;
letter-spacing:.15em;margin:10px 0 4px 2px}}
input{{width:100%;height:38px;padding:0 12px;border:1px solid #e5e2d9;background:white;
color:#1d1b16;border-radius:8px;font-size:13px;font-family:monospace;outline:none;transition:border-color .15s}}
input:focus{{border-color:#c45f3d;box-shadow:0 0 0 3px rgba(196,95,61,.08)}}
.actions{{display:flex;gap:6px}}
.btn{{height:34px;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;padding:0 14px;transition:all .15s}}
.btn-del{{background:#fbe7e1;color:#b04a3d}} .btn-del:hover{{background:#f8d5ce}}
.btn-tst{{background:#f0f0ea;color:#3d3929}} .btn-tst:hover{{background:#e5e2d9}}
.btn-add{{background:#e6f2eb;color:#2d6a4f;width:100%;height:40px;font-size:13px;margin-top:4px}}
.btn-add:hover{{background:#d0e8d8}}
.btn-save{{background:#c45f3d;color:white;width:100%;height:46px;font-size:15px;margin-top:16px;border-radius:12px}}
.btn-save:hover{{background:#b0512f}}
.ts{{font-size:11px;margin-top:6px;min-height:16px;font-weight:600}}
.st{{padding:11px 16px;border-radius:10px;margin-bottom:16px;font-size:13px;font-weight:600;display:none}}
.ok{{display:block;background:#e6f2eb;color:#2d6a4f}}
.er{{display:block;background:#fbe7e1;color:#b04a3d}}
</style></head>
<body><div class="w">
  <h1>CFC Backend Settings</h1>
  <p class="sub">First backend whose models list matches the request model wins.<br>
    Empty models list = catch-all (put last). Changes apply instantly on save.</p>
  <div id="st" class="st"></div>
  <div id="list"></div>
  <button class="btn btn-add" onclick="addBackend()">+ Add Backend</button>
  <button class="btn btn-save" onclick="save()">Save &amp; Apply</button>
</div>
<script>
let B=[];
function esc(s){{return String(s||"").replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}}
function st(m,e){{const el=document.getElementById("st");el.textContent=m;el.className="st "+(e?"er":"ok")}}
function render(){{
  const el=document.getElementById("list");
  el.innerHTML=B.map((b,i)=>
  `<div class="backend" id="b${{i}}">
    <div class="bhead">
      <span class="bname">${{esc(b.name)||"Backend "+(i+1)}}</span>
      ${{!b.models?.length?"<span class='badge'>catch-all</span>":""}}
      <div class="actions">
        <button class="btn btn-tst" onclick="testBackend(${{i}})">Test</button>
        ${{B.length>1?"<button class='btn btn-del' onclick='del("+(i)+")'>Remove</button>":""}}
      </div>
    </div>
    <div class="row">
      <div>
        <label>Name</label>
        <input value="${{esc(b.name)}}" onchange="upd(${{i}},'name',this.value)" placeholder="e.g. Local LLM">
      </div>
      <div>
        <label>Base URL (ends in /v1)</label>
        <input value="${{esc(b.url)}}" onchange="upd(${{i}},'url',this.value)" placeholder="http://127.0.0.1:1234/v1">
      </div>
    </div>
    <label>API Key (blank = pass through extension key)</label>
    <input type="password" value="${{esc(b.key)}}" onchange="upd(${{i}},'key',this.value)" placeholder="sk-...">
    <label>Models (comma-separated &mdash; blank = catch-all)</label>
    <input value="${{esc((b.models||[]).join(", "))}}"
      onchange="upd(${{i}},'models',this.value.split(',').map(s=>s.trim()).filter(Boolean))"
      placeholder="claude-opus-4-7, claude-sonnet-4-6">
    <div class="ts" id="ts${{i}}"></div>
  </div>`).join("");
}}
window.upd=function(i,k,v){{B[i][k]=v}};
window.del=function(i){{B.splice(i,1);render()}};
window.addBackend=function(){{
  B.push({{name:"",url:"http://127.0.0.1:1234/v1",key:"",models:[]}});
  render();
  setTimeout(()=>document.getElementById("b"+(B.length-1))?.scrollIntoView({{behavior:"smooth"}}),50);
}};
window.testBackend=async function(i){{
  const b=B[i],el=document.getElementById("ts"+i);
  el.textContent="Testing...";el.style.color="#6b6651";
  try{{
    const h=b.key?{{Authorization:"Bearer "+b.key}}:{{}};
    const r=await fetch(b.url.replace(/\\/v1\\/?$/,"")+"/v1/models",{{headers:h}});
    if(r.ok){{
      const d=await r.json();
      const names=(d.data||[]).map(m=>m.id).slice(0,4).join(", ")||"OK";
      el.textContent="✓ "+names;el.style.color="#2d6a4f";
    }}else{{el.textContent="✗ HTTP "+r.status;el.style.color="#b04a3d"}}
  }}catch(e){{el.textContent="✗ "+e.message;el.style.color="#b04a3d"}}
}};
window.save=async function(){{
  try{{
    const r=await fetch("/api/backends",{{
      method:"POST",headers:{{"Content-Type":"application/json"}},
      body:JSON.stringify({{backends:B}})}});
    const d=await r.json();
    if(d.ok)st("✓ Saved and applied");
    else st("Error: "+(d.error||"unknown"),true);
  }}catch(e){{st("Save failed: "+e.message,true)}}
}};
async function load(){{
  try{{
    const r=await fetch("/api/backends");
    const d=await r.json();
    B=d.backends||[];
    if(!B.length)B=[{{name:"Default",url:"http://127.0.0.1:1234/v1",key:"",models:[]}}];
    render();
  }}catch(e){{st("Cannot reach proxy: "+e.message,true)}}
}}
load();
</script></body></html>"""


# ---------- HTTP handler (verbatim 12.py MultiC2Handler with FIX 1) ---------

class MultiC2Handler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        try:
            print(f" [{time.strftime('%H:%M:%S')}] {args[0]}")
        except Exception:
            pass

    def handle_one_request(self):
        try:
            super().handle_one_request()
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, OSError):
            pass

    # ---- response helpers --------------------------------------------------

    def _json(self, data, status=200):
        b = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Connection", "close")
        self._cors()
        self.end_headers()
        try:
            self.wfile.write(b)
        except OSError:
            pass

    def _html(self, html, status=200):
        b = html.encode()
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Connection", "close")
        self._cors()
        self.end_headers()
        try:
            self.wfile.write(b)
        except OSError:
            pass

    def _204(self):
        self.send_response(204)
        self.send_header("Connection", "close")
        self._cors()
        self.end_headers()

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header(
            "Access-Control-Allow-Methods", "GET, POST, PATCH, OPTIONS"
        )
        self.send_header(
            "Access-Control-Allow-Headers",
            "Content-Type, Cache-Control, anthropic-version, anthropic-beta, "
            "anthropic-client-platform, anthropic-client-version, "
            "Authorization, x-app, x-service-name, x-api-key",
        )
        self.send_header("Access-Control-Allow-Private-Network", "true")

    # ---- routing predicates ------------------------------------------------

    def _is_auth(self, p):
        if p.startswith("/https://") or p.startswith("/http://"):
            return True
        if p.startswith("/chrome-extension://"):
            return True
        return any(
            s in p
            for s in [
                "/oauth/",
                "/bootstrap",
                "/domain_info",
                "/chat_conversations",
                "/organizations",
                "/url_hash_check",
                "/api/web/",
                "/features/",
                "/spotlight",
                "/usage",
                "/entitlements",
                "/flags",
                "/mcp/v2/",
                # FIX 1 -- bare /profile, /account, /auth catches so
                # request.js's profile / account / auth fetches answer
                # locally instead of being forwarded to LM Studio.
                "/profile",
                "/account",
                "/auth/profile",
            ]
        )

    def _is_v1(self, p):
        # Original 12.py logic, plus FIX 1: exclude profile/account/auth
        # so they fall through to _is_auth.
        if "/v1/oauth" in p:
            return False
        if "/v1/profile" in p or "/v1/account" in p or "/v1/auth" in p:
            return False
        return "/v1/" in p and (
            "api.anthropic.com" in p
            or p.startswith("/v1/")
            or p.startswith("/<https://api.anthropic.com/v1/>")
        )

    # ---- v1 forward (verbatim 12.py) --------------------------------------

    def _forward_v1(self, method, body):
        model = ""
        if body:
            try:
                model = json.loads(body).get("model", "")
            except Exception:
                pass
        p = self.path
        if p.startswith("/https://") or p.startswith("/http://"):
            inner = p[1:]
            idx = inner.find("/v1/")
            suffix = inner[idx:] if idx != -1 else "/v1"
        else:
            suffix = p
        path_suffix = suffix[3:] if suffix.startswith("/v1") else suffix
        base_hdrs = {
            k: v
            for k, v in self.headers.items()
            if k.lower()
            in (
                "content-type",
                "accept",
                "anthropic-version",
                "anthropic-beta",
                "anthropic-client-platform",
                "anthropic-client-version",
            )
        }
        ext_auth = self.headers.get("Authorization", "")
        last_err = None
        for backend in _pick_backends(model):
            target = backend["url"].rstrip("/") + path_suffix
            hdrs = dict(base_hdrs)
            if backend.get("key"):
                hdrs["Authorization"] = f"Bearer {backend['key']}"
            elif ext_auth:
                hdrs["Authorization"] = ext_auth
            req = urllib.request.Request(
                target, data=body or None, headers=hdrs, method=method
            )
            try:
                with urllib.request.urlopen(req, timeout=300) as r:
                    data = r.read()
                    self.send_response(r.status)
                    for h in (
                        "Content-Type",
                        "Content-Length",
                        "Transfer-Encoding",
                    ):
                        v = r.headers.get(h)
                        if v:
                            self.send_header(h, v)
                    self.send_header("Connection", "close")
                    self._cors()
                    self.end_headers()
                    try:
                        self.wfile.write(data)
                    except OSError:
                        pass
                    return
            except urllib.error.HTTPError as e:
                if e.code < 500:
                    data = e.read() or b""
                    self.send_response(e.code)
                    self.send_header(
                        "Content-Type",
                        e.headers.get("Content-Type", "application/json"),
                    )
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Connection", "close")
                    self._cors()
                    self.end_headers()
                    try:
                        self.wfile.write(data)
                    except OSError:
                        pass
                    return
                last_err = e
            except Exception as ex:
                last_err = ex
        err_msg = json.dumps(
            {"error": {"type": "proxy_error", "message": str(last_err)}}
        ).encode()
        self.send_response(502)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(err_msg)))
        self.send_header("Connection", "close")
        self._cors()
        self.end_headers()
        try:
            self.wfile.write(err_msg)
        except OSError:
            pass

    # ---- HTTP method handlers (verbatim 12.py) ----------------------------

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Connection", "close")
        self._cors()
        self.end_headers()

    def do_GET(self):
        p = self.path
        # /v1/* (except /v1/oauth, /v1/profile, /v1/account, /v1/auth) -> backend
        if self._is_v1(p):
            self._forward_v1("GET", b"")
            return
        if p.startswith("/api/options"):
            # 12.py contract: ui:{}, uiNodes:[]  -- the server NEVER replaces
            # extension UI elements.  The Backend Settings link in
            # /options.html is injected by request.js itself
            # (MutationObserver next to Log out).
            self._json(
                {
                    "mode": "",
                    "cfcBase": CFC_BASE,
                    "anthropicBaseUrl": DEFAULT_BACKEND_URL,
                    "apiBaseIncludes": ["https://api.anthropic.com/v1/"],
                    "proxyIncludes": [
                        "https://api.anthropic.com/v1/",
                        "cdn.segment.com",
                        "featureassets.org",
                        "assetsconfigcdn.org",
                        "featuregates.org",
                        "api.segment.io",
                        "prodregistryv2.org",
                        "beyondwickedmapping.org",
                        "api.honeycomb.io",
                        "statsigapi.net",
                        "events.statsigapi.net",
                        "api.statsigcdn.com",
                        "*ingest.us.sentry.io",
                        "https://api.anthropic.com/api/oauth/profile",
                        "https://api.anthropic.com/api/bootstrap",
                        "https://console.anthropic.com/v1/oauth/token",
                        "https://platform.claude.com/v1/oauth/token",
                        "https://api.anthropic.com/api/oauth/account",
                        "https://api.anthropic.com/api/oauth/organizations",
                        "https://api.anthropic.com/api/oauth/chat_conversations",
                        "/api/web/domain_info/browser_extension",
                        "/api/web/url_hash_check/browser_extension",
                    ],
                    "discardIncludes": [
                        "cdn.segment.com",
                        "api.segment.io",
                        "events.statsigapi.net",
                        "api.honeycomb.io",
                        "prodregistryv2.org",
                        "*ingest.us.sentry.io",
                        "browser-intake-us5-datadoghq.com",
                        "fpjs.dev",
                        "openfpcdn.io",
                        "googletagmanager.com",
                    ],
                    "modelAlias": {},
                    "ui": {},
                    "uiNodes": [],
                }
            )
            return
        if p.startswith("/api/backends"):
            self._json({"backends": BACKENDS})
            return
        if p.startswith("/api/arc-split-view"):
            self._json({"html": "<div>CFC Proxy</div>"})
            return
        if p.startswith("/assets/backend_settings_ui.js"):
            f = OUTPUT_DIR / "assets" / "backend_settings_ui.js"
            if f.exists():
                b = f.read_bytes()
                self.send_response(200)
                self.send_header(
                    "Content-Type", "application/javascript; charset=utf-8"
                )
                self.send_header("Content-Length", str(len(b)))
                self.send_header("Connection", "close")
                self._cors()
                self.end_headers()
                try:
                    self.wfile.write(b)
                except OSError:
                    pass
            else:
                self._204()
            return
        if "/oauth/authorize" in p:
            qs = urlparse(p).query
            self.send_response(302)
            self.send_header(
                "Location", f"{CFC_BASE}oauth/redirect?{qs}"
            )
            self.send_header("Connection", "close")
            self._cors()
            self.end_headers()
            return
        if p.startswith("/oauth/redirect"):
            self._html(_redirect_page_html())
            return
        if p.startswith("/backend_settings"):
            self._html(_build_proxy_settings_html())
            return
        if self._is_auth(p):
            self._json(get_local_auth(p))
            return
        if p in ("/",) or p.startswith("/?"):
            self._html(
                f"""<!DOCTYPE html>
<html><head><title>CFC Proxy</title></head>
<body style="background:#f9f8f3;font-family:sans-serif;padding:40px;color:#3d3929">
<h1>CFC Multi-C2 Proxy &mdash; Port {CFC_PORT}</h1>
<p>Model-based routing to multiple backends &middot; per-backend keys &middot; failover &middot; auth answered locally</p>
<p><a href="/backend_settings" style="color:#c45f3d">⚙️ Backend Settings (proxy)</a></p>
<p><a href="chrome-extension://{EXTENSION_ID}/options.html#backendsettings" style="color:#c45f3d">⚙️ Backend Settings (extension)</a></p>
</body></html>"""
            )
            return
        self._204()

    def do_POST(self):
        cl = int(self.headers.get("Content-Length", 0) or 0)
        body = self.rfile.read(cl) if cl > 0 else b""
        p = self.path
        if p.startswith("/api/backends"):
            try:
                cfg = json.loads(body or b"{}")
                bs = cfg.get("backends", [])
                if not isinstance(bs, list) or not bs:
                    self._json(
                        {"ok": False, "error": "backends must be a non-empty list"},
                        400,
                    )
                    return
                BACKENDS.clear()
                BACKENDS.extend(bs)
                _save_backends()
                self._json({"ok": True})
            except Exception as ex:
                self._json({"ok": False, "error": str(ex)}, 400)
            return
        if self._is_v1(p):
            self._forward_v1("POST", body)
            return
        if self._is_auth(p):
            self._json(get_local_auth(p))
            return
        self._204()

    def do_PATCH(self):
        cl = int(self.headers.get("Content-Length", 0) or 0)
        body = self.rfile.read(cl) if cl > 0 else b""
        p = self.path
        if self._is_v1(p):
            self._forward_v1("PATCH", body)
            return
        if self._is_auth(p):
            self._json(get_local_auth(p))
            return
        self._204()


# ---------- server ----------------------------------------------------------

class MultiC2Server(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


def start_multi_c2():
    try:
        server = MultiC2Server((CFC_BIND, CFC_PORT), MultiC2Handler)
    except OSError as e:
        print(f"[ERROR] Cannot bind {CFC_BIND}:{CFC_PORT} -- {e}")
        return None
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(f"[OK] CFC multi-backend proxy running on {CFC_BASE}")
    return server


def main():
    print("=" * 62)
    print(" CFCBASE flat standalone proxy (no wrappers)")
    print(f" Started: {datetime.now().isoformat(timespec='seconds')}")
    print("=" * 62)
    print(f" Listen:           {CFC_BASE}  (bind {CFC_BIND}:{CFC_PORT})")
    print(f" Default backend:  {DEFAULT_BACKEND_URL}")
    print(f" Backends file:    {BACKENDS_FILE.resolve()}")
    print(f" Extension dir:    {OUTPUT_DIR.resolve()}")
    print(f" Backend Settings (proxy):     {BACKEND_SETTINGS_URL}")
    print(
        f" Backend Settings (extension): "
        f"chrome-extension://{EXTENSION_ID}/options.html#backendsettings"
    )
    print("")
    print(" To eliminate /profile 404s in request.js, set the API Base URL")
    print(f" in Backend Settings to:  {CFC_BASE}v1")
    print(" so /v1/profile flows through this proxy and is answered locally.")
    print("")
    server = start_multi_c2()
    if not server:
        sys.exit(1)
    print(" Ctrl+C to stop.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[stop] shutting down")
        server.shutdown()


if __name__ == "__main__":
    main()
