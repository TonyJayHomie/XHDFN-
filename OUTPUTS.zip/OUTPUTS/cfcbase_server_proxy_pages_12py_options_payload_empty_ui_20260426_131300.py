#!/usr/bin/env python3
"""
Standalone CFCBASE wrapper.

Correct hook for /api/options:
  cfcbase_server_only_20260426_025208.py uses options_payload()

This wrapper keeps the proxy/domain pages from 12 - Copy.py, but restores the
12.py /api/options UI contract:
  ui: {}
  uiNodes: []

So the server cannot replace Permissions, Shortcuts, Options, Microphone,
Log out, sidepanel login, beta warning, or arbitrary buttons.

No existing files are edited.
No request.js changes.
"""

import importlib.util
from pathlib import Path


BASE_WRAPPER = (
    Path(__file__).resolve().parent
    / "cfcbase_server_proxy_pages_from_12py_20260426_124457.py"
)

spec = importlib.util.spec_from_file_location("cfcbase_server_proxy_pages_from_12py", BASE_WRAPPER)
wrapped = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wrapped)


def empty_ui_nodes():
    return []


_original_options_payload = wrapped.cfc.options_payload


def options_payload_12py_contract():
    data = _original_options_payload()
    data["ui"] = {}
    data["uiNodes"] = []
    return data


wrapped.cfc.safe_ui_nodes = empty_ui_nodes
wrapped.cfc.options_payload = options_payload_12py_contract


if __name__ == "__main__":
    wrapped.cfc.main()
