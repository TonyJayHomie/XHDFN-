#!/usr/bin/env python3
"""
Standalone CFCBASE wrapper using the proxy-served page split from 12 - Copy.py.

No existing project files are edited.
No request.js changes.

Routes:
  /backend_settings  -> proxy/domain-served darker backend settings page
  /oauth/authorize   -> Cocodem-looking local auth gate with Enter / Skip
  /api/* and /v1/*   -> inherited from cfcbase_server_only_20260426_025208.py
"""

import importlib.util
from pathlib import Path
from urllib.parse import parse_qs


BASE_SERVER = (
    Path(__file__).resolve().parent
    / "cfcbase_server_only_20260426_025208.py"
)

spec = importlib.util.spec_from_file_location("cfcbase_server_20260426_025208", BASE_SERVER)
cfc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cfc)


def proxy_backend_settings_html():
    backends_json = cfc.json.dumps(cfc.BACKENDS)
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Backend Settings</title>
<style>
*{{box-sizing:border-box}}
body{{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#19182c;color:#f5f3ee;margin:0;padding:32px 20px;min-height:100vh}}
.wrap{{max-width:980px;margin:0 auto}}
h1{{font-size:28px;color:#ff4568;margin:0 0 4px;font-weight:800}}
.sub{{color:#7f82a8;margin:0 0 28px}}
.panel{{background:#142447;border:1px solid #20345f;border-radius:12px;padding:22px;margin:18px auto;max-width:760px}}
.panel h2{{font-size:16px;color:#ff4568;margin:0 0 16px}}
.backend{{border:1px dashed #243963;border-radius:10px;padding:14px;margin:10px 0;background:#121c36}}
.grid{{display:grid;grid-template-columns:160px 1fr;gap:12px;align-items:center;margin:10px 0}}
label{{color:#7f82a8;font-size:14px}}
input,textarea,select{{width:100%;background:#17172b;color:#f5f3ee;border:1px solid #ef4565;border-radius:6px;padding:11px;font-size:14px;font-family:monospace}}
input:focus,textarea:focus,select:focus{{outline:none;box-shadow:0 0 0 2px rgba(239,69,101,.15)}}
.muted{{color:#7f82a8}}
.actions{{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}}
button{{background:#ef4565;color:white;border:0;border-radius:6px;padding:10px 16px;font-weight:700;cursor:pointer}}
button.secondary{{background:#202842;color:#d8d7e8;border:1px solid #303b62}}
button.danger{{background:#3a1730;color:#ff4568;border:1px solid #73304c}}
.save{{display:block;max-width:760px;margin:18px auto 0;width:100%;font-size:18px;padding:16px;border-radius:8px}}
.status{{display:none;margin:0 auto 16px;max-width:760px;padding:12px 16px;border-radius:8px;font-weight:700}}
.ok{{display:block;background:#164f36;color:#9af0ba}}
.err{{display:block;background:#4b1b2b;color:#ff9bb0}}
.arch{{background:#17172b;border:1px solid #2b2a44;border-radius:8px;padding:14px;color:#7f82a8;font-family:monospace;font-size:13px;line-height:1.7}}
code{{background:#0f1a32;color:#7ff0b2;border-radius:4px;padding:2px 5px}}
</style></head>
<body><div class="wrap">
  <h1>OpenClaw -- Backend Setup</h1>
  <p class="sub">Configure backends · test connections · connect to extension</p>
  <div id="status" class="status"></div>
  <section class="panel">
    <h2>API Backends</h2>
    <div id="backendList"></div>
    <button class="secondary" onclick="addBackend()">+ Add Backend</button>
  </section>
  <section class="panel">
    <h2>Extension Routing & Auth Bypass</h2>
    <div class="grid"><label>cfcBase URL</label><input id="cfcBase" value="{cfc.LOCAL_BASE}"></div>
    <div class="grid"><label>apiBaseUrl</label><input id="apiBaseUrl" value="{cfc.IDENTITY.get('apiBaseUrl') or cfc.DEFAULT_BACKEND_URL}"></div>
    <div class="grid"><label>Mode</label><select id="mode"><option value="">api -- local / custom backend</option><option value="claude">claude -- official</option></select></div>
    <div class="grid"><label>Access Token</label><input id="authToken" value="{cfc.IDENTITY.get('authToken','')}" placeholder="blank = auto-generate bypass token"></div>
  </section>
  <section class="panel">
    <h2>Quick Actions</h2>
    <div class="actions">
      <button onclick="testAll()">Test All Backends</button>
      <button onclick="fetchModels()">Fetch All Models</button>
      <button class="secondary" onclick="resetDefaults()">Reset to Defaults</button>
      <button class="danger" onclick="clearData()">Clear All Data & Reload</button>
    </div>
  </section>
  <section class="panel">
    <h2>Architecture</h2>
    <div class="arch">
      <b>OpenClaw Gateway:</b> {cfc.DEFAULT_BACKEND_URL}<br>
      <b>CFCBASE Local:</b> {cfc.LOCAL_BASE}<br>
      <b>CFCBASE Remote:</b> {cfc.REMOTE_BASE}<br><br>
      <code>localStorage.apiBaseUrl</code> takes priority over all routing in request.js.<br>
      Bypass token uses <code>iss:"cfc"</code> and is served locally by the proxy.
    </div>
  </section>
  <button class="save" onclick="saveConfig()">Save Config & Connect to Extension -></button>
</div>
<script>
let backends = {backends_json};
function esc(s){{return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;")}}
function status(msg, ok=true){{const el=document.getElementById("status");el.textContent=msg;el.className="status "+(ok?"ok":"err")}}
function renderBackends(){{
  const list=document.getElementById("backendList");
  list.innerHTML=backends.map((b,i)=>`<div class="backend">
    <div class="grid"><label>Name</label><input value="${{esc(b.name||"")}}" onchange="backends[${{i}}].name=this.value"></div>
    <div class="grid"><label>Base URL</label><input value="${{esc(b.url||"")}}" onchange="backends[${{i}}].url=this.value"></div>
    <div class="grid"><label>API Key</label><input type="password" value="${{esc(b.key||"")}}" onchange="backends[${{i}}].key=this.value"></div>
    <div class="grid"><label>Models</label><textarea onchange="backends[${{i}}].models=this.value.split(',').map(x=>x.trim()).filter(Boolean)">${{esc((b.models||[]).join(", "))}}</textarea></div>
    <div class="actions"><button class="secondary" onclick="testBackend(${{i}})">Test</button>${{backends.length>1?`<button class="danger" onclick="removeBackend(${{i}})">Remove</button>`:""}}</div>
    <div class="muted" id="backendStatus${{i}}"></div>
  </div>`).join("");
}}
function addBackend(){{backends.push({{name:"",url:"http://127.0.0.1:1234/v1",key:"",models:[],enabled:true,modelAlias:{{}}}});renderBackends()}}
function removeBackend(i){{backends.splice(i,1);renderBackends()}}
async function testBackend(i){{
  const b=backends[i], el=document.getElementById("backendStatus"+i);
  el.textContent="Testing...";
  try{{
    const headers=b.key?{{Authorization:"Bearer "+b.key}}:{{}};
    const r=await fetch((b.url||"").replace(/\\/v1\\/?$/,"")+"/v1/models",{{headers}});
    if(!r.ok) throw new Error("HTTP "+r.status);
    const d=await r.json();
    el.textContent="Connected! Models: "+((d.data||[]).map(m=>m.id).slice(0,5).join(", ")||"OK");
  }}catch(e){{el.textContent="Failed: "+e.message}}
}}
async function testAll(){{for(let i=0;i<backends.length;i++) await testBackend(i); status("Backend tests complete")}}
async function fetchModels(){{await testAll()}}
function resetDefaults(){{backends=[{{name:"Default",url:"http://127.0.0.1:1234/v1",key:"",models:[],enabled:true,modelAlias:{{}}}}];renderBackends();status("Defaults restored")}}
async function clearData(){{localStorage.removeItem("apiBaseUrl");status("Local browser routing data cleared");}}
async function saveConfig(){{
  const identity={{apiBaseUrl:document.getElementById("apiBaseUrl").value,authToken:document.getElementById("authToken").value,mode:document.getElementById("mode").value}};
  const br=await fetch("/api/backends",{{method:"POST",headers:{{"Content-Type":"application/json"}},body:JSON.stringify({{backends}})}});
  const ir=await fetch("/api/identity",{{method:"POST",headers:{{"Content-Type":"application/json"}},body:JSON.stringify(identity)}});
  localStorage.setItem("apiBaseUrl",identity.apiBaseUrl);
  if(br.ok && ir.ok) status("Saved config and connected to extension");
  else status("Save failed", false);
}}
renderBackends();
</script></body></html>"""


def authorize_gate_html(query):
    params = parse_qs(query, keep_blank_values=True)
    redirect_uri = params.get("redirect_uri", [""])[0]
    state = params.get("state", [""])[0]
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Authenticating...</title>
<style>
body{{background:#f9f8f3;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;color:#1d1b16}}
.box{{background:white;border:1px solid #e5e2d9;border-radius:32px;padding:40px;max-width:420px;width:100%;text-align:center;box-shadow:0 12px 40px rgba(0,0,0,.04)}}
.logo{{width:72px;height:72px;border-radius:20px;border:1px solid #e5e2d9;margin:0 auto 20px;display:flex;align-items:center;justify-content:center;color:#d97757;font-size:38px}}
h1{{font-family:"Iowan Old Style",Georgia,serif;font-weight:400;margin:0 0 10px;font-size:28px}}
p{{color:#6b6651;font-size:14px;line-height:1.5;margin:0 0 24px}}
button{{height:44px;padding:0 24px;background:#c45f3d;color:white;border:0;border-radius:12px;font-size:15px;font-weight:800;cursor:pointer}}
</style></head>
<body><div class="box">
  <div class="logo">✺</div>
  <h1>Claude in Chrome</h1>
  <p>Local CFC authentication is ready. No real login is required.</p>
  <button id="enter">Enter / Skip</button>
</div>
<script>
document.getElementById("enter").onclick = () => {{
  const redirectUri = {cfc.json.dumps(redirect_uri)};
  const state = {cfc.json.dumps(state)};
  const u = new URL("{cfc.LOCAL_BASE}oauth/redirect");
  if (redirectUri) u.searchParams.set("redirect_uri", redirectUri);
  if (state) u.searchParams.set("state", state);
  location.href = u.toString();
}};
</script></body></html>"""


original_do_get = cfc.Handler.do_GET


def patched_do_get(self):
    parsed = cfc.urlparse(self.path)
    if parsed.path.startswith("/backend_settings"):
        self.send_html(proxy_backend_settings_html())
        return
    if parsed.path.startswith("/oauth/authorize"):
        self.send_html(authorize_gate_html(parsed.query))
        return
    return original_do_get(self)


cfc.Handler.do_GET = patched_do_get


if __name__ == "__main__":
    cfc.main()
