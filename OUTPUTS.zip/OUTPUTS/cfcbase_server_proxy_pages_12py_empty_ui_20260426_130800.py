#!/usr/bin/env python3
"""
Standalone CFCBASE wrapper.

Uses the same /api/options UI-node behavior as 12 - Copy.py:
  ui: {}
  uiNodes: []

That means the CFC server will not replace arbitrary buttons in options.html
or sidepanel.html. Backend settings stays served by the proxy route:
  http://localhost:8520/backend_settings

No existing files are edited.
No request.js changes.
"""

import importlib.util
from pathlib import Path


BASE_WRAPPER = (
    Path(__file__).resolve().parent
    / "cfcbase_server_proxy_pages_from_12py_20260426_124457.py"
)

spec = importlib.util.spec_from_file_location("cfcbase_server_proxy_pages_from_12py", BASE_WRAPPER)
wrapped = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wrapped)


def empty_ui_nodes():
    return []


wrapped.cfc.safe_ui_nodes = empty_ui_nodes


_original_build_options_response = getattr(wrapped.cfc, "_build_options_response", None)


def build_options_response_12py_contract():
    if _original_build_options_response:
        data = _original_build_options_response()
    else:
        data = {}
    data["ui"] = {}
    data["uiNodes"] = []
    return data


if _original_build_options_response:
    wrapped.cfc._build_options_response = build_options_response_12py_contract


if __name__ == "__main__":
    wrapped.cfc.main()
