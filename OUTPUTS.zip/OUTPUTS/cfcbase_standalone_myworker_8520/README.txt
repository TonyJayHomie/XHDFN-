Standalone CFCBASE proof folder.

Remote replacement:
https://myworker.mahnikka.workers.dev/

Local replacement:
http://localhost:8520/

No existing project files are edited by this folder.
