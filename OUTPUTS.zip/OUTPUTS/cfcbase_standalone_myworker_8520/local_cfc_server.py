#!/usr/bin/env python3
"""
Standalone CFC local server.

This is the localhost:8787 replacement:
  http://localhost:8520/

It is intentionally standalone and writes state only beside this file.
It does not edit main.py, COCO TEST, or the original Cocodem source.
"""

import base64
import json
import mimetypes
import os
import shutil
import time
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from socketserver import TCPServer, ThreadingMixIn
from urllib.parse import parse_qs, quote, urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError

REMOTE_BASE = "https://myworker.mahnikka.workers.dev/"
LOCAL_BASE = "http://localhost:8520/"
PORT = 8520
ROOT = Path(__file__).resolve().parent
STATE_FILE = ROOT / "backend_settings_state.json"
BACKENDS_FILE = ROOT / "backends.json"

USER_UUID = "ac507011-00b5-56c4-b3ec-ad820dbafbc1"
ORG_UUID = "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08"
EMAIL = "free@claudeagent.ai"
EXTENSION_ID = "fcoeoabgfenejglbffodgkkbkcdhcgfn"

DISCARD = [
    "cdn.segment.com",
    "api.segment.io",
    "events.statsigapi.net",
    "api.honeycomb.io",
    "prodregistryv2.org",
    "ingest.us.sentry.io",
    "browser-intake-us5-datadoghq.com",
    "fpjs.dev",
    "openfpcdn.io",
    "api.fpjs.io",
    "googletagmanager.com",
]

PROXY_INCLUDES = [
    "cdn.segment.com",
    "featureassets.org",
    "assetsconfigcdn.org",
    "featuregates.org",
    "api.segment.io",
    "prodregistryv2.org",
    "beyondwickedmapping.org",
    "api.honeycomb.io",
    "statsigapi.net",
    "events.statsigapi.net",
    "api.statsigcdn.com",
    "*ingest.us.sentry.io",
    "https://api.anthropic.com/api/oauth/profile",
    "https://api.anthropic.com/api/bootstrap",
    "https://console.anthropic.com/v1/oauth/token",
    "https://platform.claude.com/v1/oauth/token",
    "https://api.anthropic.com/api/oauth/account",
    "https://api.anthropic.com/api/oauth/organizations",
    "https://api.anthropic.com/api/oauth/chat_conversations",
    "/api/web/domain_info/browser_extension",
]


def _load_json(path, default):
    try:
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, type(default)):
                return data
    except Exception:
        pass
    return default


def _save_json(path, data):
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _b64url(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _jwt():
    header = _b64url(json.dumps({"alg": "none", "typ": "JWT"}).encode())
    payload = _b64url(json.dumps({
        "iss": "cfc",
        "sub": USER_UUID,
        "exp": 9999999999,
        "iat": 1700000000,
    }).encode())
    return header + "." + payload + ".local"


def token_response():
    tok = _jwt()
    return {
        "access_token": tok,
        "token_type": "bearer",
        "expires_in": 315360000,
        "refresh_token": tok,
        "scope": "user:profile user:inference user:chat",
    }


ACCOUNT = {
    "uuid": USER_UUID,
    "id": USER_UUID,
    "email_address": EMAIL,
    "email": EMAIL,
    "full_name": "Local User",
    "name": "Local User",
    "display_name": "Local User",
    "has_password": True,
    "has_completed_onboarding": True,
    "preferred_language": "en-US",
    "has_claude_pro": True,
    "settings": {"theme": "system", "language": "en-US"},
}

ORG = {
    "uuid": ORG_UUID,
    "id": ORG_UUID,
    "name": "Local",
    "role": "admin",
    "organization_type": "personal",
    "billing_type": "self_serve",
    "capabilities": ["chat", "claude_pro_plan", "api", "computer_use", "claude_for_chrome"],
    "rate_limit_tier": "default_claude_pro",
    "settings": {},
}

PROFILE = {
    **ACCOUNT,
    "account": ACCOUNT,
    "organization": ORG,
    "organizations": [ORG],
    "memberships": [{"organization": ORG, "role": "admin", "joined_at": "2024-01-01T00:00:00Z"}],
    "active_organization_uuid": ORG_UUID,
}

BOOTSTRAP = {
    **PROFILE,
    "account_uuid": USER_UUID,
    "statsig": {
        "user": {"userID": USER_UUID, "custom": {"organization_uuid": ORG_UUID}},
        "values": {"feature_gates": {}, "dynamic_configs": {}, "layer_configs": {}},
    },
    "flags": {},
    "features": [],
    "active_flags": {},
    "active_subscription": {
        "plan": "claude_pro",
        "status": "active",
        "type": "claude_pro",
        "billing_period": "monthly",
        "current_period_start": "2024-01-01T00:00:00Z",
        "current_period_end": "2099-12-31T23:59:59Z",
    },
    "chat_enabled": True,
}


def options_response():
    return {
        "mode": "",
        "anthropicBaseUrl": "",
        "apiBaseIncludes": ["https://api.anthropic.com/v1/"],
        "proxyIncludes": PROXY_INCLUDES,
        "discardIncludes": [
            "cdn.segment.com",
            "api.segment.io",
            "events.statsigapi.net",
            "api.honeycomb.io",
            "prodregistryv2.org",
            "*ingest.us.sentry.io",
            "browser-intake-us5-datadoghq.com",
        ],
        "modelAlias": {},
        "ui": {},
        "uiNodes": [],
    }


def auth_response(path):
    if "/oauth/token" in path:
        return token_response()
    if "/oauth/profile" in path or "/oauth/account" in path:
        return PROFILE
    if "/bootstrap" in path:
        return BOOTSTRAP
    if "/oauth/organizations" in path:
        return [ORG]
    if "/chat_conversations" in path:
        return {"conversations": [], "limit": 0, "has_more": False, "cursor": None}
    if "/domain_info" in path:
        return {"domain": "local", "allowed": True}
    if "/url_hash_check" in path:
        return {"allowed": True}
    if "/licenses/verify" in path:
        return {"valid": True, "license": "local", "tier": "pro", "expires": "2099-12-31"}
    if "/mcp/v2/bootstrap" in path:
        return {"servers": [], "tools": [], "enabled": False}
    if "/usage" in path:
        return {"usage": {}, "limit": None}
    if "/entitlements" in path:
        return {"entitlements": []}
    if "/flags" in path or "/features/" in path:
        return {}
    return {}


def authorize_html(query):
    q = quote(query, safe="")
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>CFC Sign In</title></head>
<body style="font-family:system-ui;background:#f9f8f3;color:#1d1b16;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
<main style="background:white;border:1px solid #e5e2d9;border-radius:24px;padding:32px;max-width:420px;text-align:center">
<h1 style="font:400 24px Georgia;margin:0 0 8px">Claude in Chrome</h1>
<p style="color:#6b6651;font-size:13px;line-height:1.5">Local CFC replacement. No Anthropic credentials are requested.</p>
<button id="go" style="background:#c45f3d;color:white;border:0;border-radius:12px;padding:12px 22px;font-weight:700;cursor:pointer">Enter</button>
<p id="msg" style="font-size:12px;color:#8b856c;margin-top:14px"></p>
</main>
<script>
const qs = decodeURIComponent("{q}");
document.getElementById("go").onclick = () => {{
  document.getElementById("msg").textContent = "Continuing...";
  location.href = "/oauth/redirect" + (qs ? "?" + qs : "");
}};
setTimeout(() => document.getElementById("go").click(), 400);
</script></body></html>"""


def redirect_html(query):
    q = quote(query, safe="")
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>Authenticating</title></head>
<body style="font-family:system-ui;background:#f9f8f3;color:#1d1b16;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
<main style="background:white;border:1px solid #e5e2d9;border-radius:24px;padding:32px;max-width:460px;text-align:center">
<h1 style="font:400 22px Georgia;margin:0 0 8px">Signed in</h1>
<p id="msg" style="color:#6b6651;font-size:13px">Finishing local CFC auth...</p>
</main>
<script>
(async () => {{
  const msg = document.getElementById("msg");
  const params = new URLSearchParams(decodeURIComponent("{q}"));
  let redirectUri = params.get("redirect_uri") || "";
  const state = params.get("state") || "";
  let eid = "{EXTENSION_ID}";
  if (redirectUri.startsWith("chrome-extension://")) {{
    try {{ eid = new URL(redirectUri).host; }} catch (e) {{}}
  }}
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  const code = Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");
  let finalUri = redirectUri;
  if (finalUri) {{
    try {{
      const u = new URL(finalUri);
      u.searchParams.set("code", code);
      if (state) u.searchParams.set("state", state);
      finalUri = u.toString();
    }} catch (e) {{
      finalUri = redirectUri + (redirectUri.includes("?") ? "&" : "?") + "code=" + code;
    }}
  }}
  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {{
    chrome.runtime.sendMessage(eid, {{type: "oauth_redirect", redirect_uri: finalUri}}, (rv) => {{
      if (chrome.runtime.lastError) {{
        msg.textContent = "Extension message failed: " + chrome.runtime.lastError.message;
        msg.style.color = "#b04a3d";
        return;
      }}
      msg.textContent = "Done. You can close this tab.";
      msg.style.color = "#2d6a4f";
      setTimeout(() => {{ try {{ window.close(); }} catch (e) {{}} }}, 800);
    }});
  }} else if (finalUri) {{
    location.href = finalUri;
  }} else {{
    msg.textContent = "Auth complete.";
    msg.style.color = "#2d6a4f";
  }}
}})();
</script></body></html>"""


def backend_settings_html():
    state = _load_json(STATE_FILE, {"backend": "http://127.0.0.1:1234/v1", "apiKey": ""})
    backend = state.get("backend", "http://127.0.0.1:1234/v1")
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>Backend Settings</title></head>
<body style="font-family:system-ui;background:#f9f8f3;color:#1d1b16;margin:0;padding:32px">
<main style="max-width:620px;margin:auto;background:white;border:1px solid #e5e2d9;border-radius:24px;padding:28px">
<h1 style="font:400 26px Georgia;margin:0 0 8px">Backend Settings</h1>
<p style="color:#6b6651">Safe replacement for Cocodem remote config. Stored locally beside the standalone server.</p>
<label style="display:block;font-size:12px;font-weight:700;margin-top:18px">Backend URL</label>
<input id="backend" value="{backend}" style="width:100%;height:42px;border:1px solid #ddd;border-radius:10px;padding:0 12px;font-family:monospace">
<label style="display:block;font-size:12px;font-weight:700;margin-top:18px">API Key (optional)</label>
<input id="apiKey" type="password" value="" style="width:100%;height:42px;border:1px solid #ddd;border-radius:10px;padding:0 12px;font-family:monospace">
<button id="save" style="margin-top:18px;background:#c45f3d;color:white;border:0;border-radius:12px;padding:12px 20px;font-weight:700">Save</button>
<button id="test" style="margin-top:18px;margin-left:8px;background:white;color:#333;border:1px solid #ddd;border-radius:12px;padding:12px 20px;font-weight:700">Test</button>
<pre id="out" style="background:#1d1b16;color:#eee;border-radius:10px;padding:12px;min-height:44px;white-space:pre-wrap"></pre>
</main>
<script>
const out = document.getElementById("out");
document.getElementById("save").onclick = async () => {{
  const body = {{backend: backend.value.trim(), apiKey: apiKey.value}};
  const r = await fetch("/api/backend_settings", {{method:"POST", headers:{{"content-type":"application/json"}}, body:JSON.stringify(body)}});
  out.textContent = JSON.stringify(await r.json(), null, 2);
}};
document.getElementById("test").onclick = async () => {{
  const root = backend.value.trim().replace(/\\/v1\\/?$/, "");
  try {{
    const r = await fetch(root + "/v1/models");
    out.textContent = "HTTP " + r.status + "\\n" + await r.text();
  }} catch (e) {{
    out.textContent = e.message;
  }}
}};
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        print("[%s] %s" % (time.strftime("%H:%M:%S"), fmt % args))

    def cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Cache-Control, Accept, anthropic-version, anthropic-beta, anthropic-client-platform, anthropic-client-version, Authorization, x-api-key, x-service-name")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "86400")

    def send_bytes(self, data, content_type="application/octet-stream", status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Connection", "close")
        self.cors()
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, obj, status=200):
        self.send_bytes(json.dumps(obj).encode("utf-8"), "application/json", status)

    def send_html(self, html, status=200):
        self.send_bytes(html.encode("utf-8"), "text/html; charset=utf-8", status)

    def no_content(self):
        self.send_response(204)
        self.send_header("Connection", "close")
        self.cors()
        self.end_headers()

    def is_discard(self):
        return any(x in self.path for x in DISCARD)

    def is_auth(self):
        p = self.path
        return (
            p.startswith("/https://") or
            p.startswith("/http://") or
            any(x in p for x in ["/oauth/", "/bootstrap", "/domain_info", "/url_hash_check", "/chat_conversations", "/organizations", "/licenses/", "/mcp/v2/", "/usage", "/entitlements", "/flags"])
        )

    def is_v1(self):
        p = self.path
        return p.startswith("/v1/") or "/v1/" in p and "oauth/token" not in p

    def v1_suffix(self):
        idx = self.path.find("/v1/")
        if idx >= 0:
            return self.path[idx + 3:]
        return self.path

    def forward_v1(self, method, body=b""):
        state = _load_json(STATE_FILE, {"backend": "http://127.0.0.1:1234/v1", "apiKey": ""})
        base = state.get("backend") or "http://127.0.0.1:1234/v1"
        target = base.rstrip("/") + self.v1_suffix()
        headers = {k: v for k, v in self.headers.items() if k.lower() in ["content-type", "accept", "authorization", "anthropic-version", "anthropic-beta", "anthropic-client-platform", "anthropic-client-version", "x-api-key"]}
        if state.get("apiKey"):
            headers["Authorization"] = "Bearer " + state["apiKey"]
        try:
            req = Request(target, data=body or None, headers=headers, method=method)
            with urlopen(req, timeout=120) as resp:
                data = resp.read()
                self.send_bytes(data, resp.headers.get("content-type", "application/json"), resp.status)
        except HTTPError as e:
            self.send_bytes(e.read(), e.headers.get("content-type", "application/json"), e.code)
        except Exception as e:
            self.send_json({"error": {"type": "proxy_error", "message": str(e), "target": target}}, 502)

    def static_file(self):
        rel = self.path.split("?", 1)[0].lstrip("/")
        if not rel:
            return False
        f = ROOT / "test_extension" / rel
        if not f.exists() or not f.is_file():
            return False
        ct = mimetypes.guess_type(str(f))[0] or "application/octet-stream"
        self.send_bytes(f.read_bytes(), ct)
        return True

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Connection", "close")
        self.cors()
        self.end_headers()

    def do_GET(self):
        if self.is_discard():
            self.no_content()
        elif self.static_file():
            return
        elif self.path.startswith("/api/options"):
            self.send_json(options_response())
        elif self.path.startswith("/api/backend_settings"):
            self.send_json(_load_json(STATE_FILE, {"backend": "http://127.0.0.1:1234/v1", "apiKey": ""}))
        elif self.path.startswith("/backend_settings"):
            self.send_html(backend_settings_html())
        elif "/oauth/authorize" in self.path:
            self.send_html(authorize_html(urlparse(self.path).query))
        elif "/oauth/redirect" in self.path:
            self.send_html(redirect_html(urlparse(self.path).query))
        elif self.is_v1():
            self.forward_v1("GET")
        elif self.is_auth():
            self.send_json(auth_response(self.path))
        elif self.path == "/" or self.path.startswith("/?"):
            self.send_html("<!doctype html><title>CFC</title><body><h1>CFC local server</h1><p>Local: %s</p><p>Remote: %s</p><p><a href='/api/options'>api/options</a> <a href='/backend_settings'>backend_settings</a></p></body>" % (LOCAL_BASE, REMOTE_BASE))
        else:
            self.send_json({"ok": True, "path": self.path})

    def do_POST(self):
        length = int(self.headers.get("content-length", "0") or "0")
        body = self.rfile.read(length) if length else b""
        if self.is_discard():
            self.no_content()
        elif self.path.startswith("/api/backend_settings"):
            try:
                data = json.loads(body.decode("utf-8") or "{}")
                state = {
                    "backend": data.get("backend") or "http://127.0.0.1:1234/v1",
                    "apiKey": data.get("apiKey") or "",
                }
                _save_json(STATE_FILE, state)
                self.send_json({"ok": True, "state": state})
            except Exception as e:
                self.send_json({"ok": False, "error": str(e)}, 400)
        elif self.is_v1():
            self.forward_v1("POST", body)
        elif self.is_auth():
            self.send_json(auth_response(self.path))
        else:
            self.send_json({"ok": True})


class Server(ThreadingMixIn, TCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    print("Standalone CFC local server")
    print("Remote replacement:", REMOTE_BASE)
    print("Local replacement: ", LOCAL_BASE)
    print("Backend settings:  ", LOCAL_BASE + "backend_settings")
    with Server(("127.0.0.1", PORT), Handler) as httpd:
        httpd.serve_forever()


if __name__ == "__main__":
    main()
