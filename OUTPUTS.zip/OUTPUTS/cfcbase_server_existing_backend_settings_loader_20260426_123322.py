#!/usr/bin/env python3
"""
Standalone CFCBASE server wrapper.

This file does not edit request.js, main.py, or any generated extension file.
It reuses the previous standalone CFCBASE server and changes only the
/backend_settings page shell so it loads the existing generated
assets/backend_settings_ui.js implementation.
"""

import importlib.util
from pathlib import Path


BASE_SERVER = (
    Path(__file__).resolve().parent
    / "cfcbase_server_only_20260426_025208.py"
)

spec = importlib.util.spec_from_file_location("cfcbase_server_20260426_025208", BASE_SERVER)
cfc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cfc)


def existing_backend_settings_html():
    return """<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <link rel="icon" type="image/svg+xml" href="/icon-128.png" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Backend Settings</title>
</head>
<body>
  <div id="__cfc_settings_container"></div>
  <script src="/assets/backend_settings_ui.js"></script>
</body>
</html>"""


cfc.backend_settings_html = existing_backend_settings_html


if __name__ == "__main__":
    cfc.main()
