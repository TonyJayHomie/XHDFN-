const REMOTE_BASE = "https://myworker.mahnikka.workers.dev/";
const LOCAL_BASE = "http://localhost:8520/";
const EXTENSION_ID = "fcoeoabgfenejglbffodgkkbkcdhcgfn";
const USER_UUID = "ac507011-00b5-56c4-b3ec-ad820dbafbc1";
const ORG_UUID = "1b61ee4a-d0ce-50b5-8b67-7eec034d3d08";
const EMAIL = "free@claudeagent.ai";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Cache-Control, Accept, anthropic-version, anthropic-beta, anthropic-client-platform, anthropic-client-version, Authorization, x-api-key, x-service-name",
  "Access-Control-Allow-Private-Network": "true",
  "Access-Control-Max-Age": "86400",
};

const DISCARD = [
  "cdn.segment.com",
  "api.segment.io",
  "events.statsigapi.net",
  "api.honeycomb.io",
  "prodregistryv2.org",
  "ingest.us.sentry.io",
  "browser-intake-us5-datadoghq.com",
  "fpjs.dev",
  "openfpcdn.io",
  "api.fpjs.io",
  "googletagmanager.com",
];

const PROXY_INCLUDES = [
  "cdn.segment.com",
  "featureassets.org",
  "assetsconfigcdn.org",
  "featuregates.org",
  "api.segment.io",
  "prodregistryv2.org",
  "beyondwickedmapping.org",
  "api.honeycomb.io",
  "statsigapi.net",
  "events.statsigapi.net",
  "api.statsigcdn.com",
  "*ingest.us.sentry.io",
  "https://api.anthropic.com/api/oauth/profile",
  "https://api.anthropic.com/api/bootstrap",
  "https://console.anthropic.com/v1/oauth/token",
  "https://platform.claude.com/v1/oauth/token",
  "https://api.anthropic.com/api/oauth/account",
  "https://api.anthropic.com/api/oauth/organizations",
  "https://api.anthropic.com/api/oauth/chat_conversations",
  "/api/web/domain_info/browser_extension",
];

function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...CORS_HEADERS,
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
    },
  });
}

function htmlResponse(body, status = 200) {
  return new Response(body, {
    status,
    headers: {
      ...CORS_HEADERS,
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}

function emptyResponse(status = 204) {
  return new Response(null, { status, headers: CORS_HEADERS });
}

function b64url(obj) {
  const text = JSON.stringify(obj);
  let bin = "";
  for (let i = 0; i < text.length; i++) bin += String.fromCharCode(text.charCodeAt(i));
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function localJwt() {
  return `${b64url({ alg: "none", typ: "JWT" })}.${b64url({
    iss: "cfc",
    sub: USER_UUID,
    exp: 9999999999,
    iat: 1700000000,
  })}.local`;
}

function tokenResponse() {
  const tok = localJwt();
  return {
    access_token: tok,
    token_type: "bearer",
    expires_in: 315360000,
    refresh_token: tok,
    scope: "user:profile user:inference user:chat",
  };
}

const ACCOUNT = {
  uuid: USER_UUID,
  id: USER_UUID,
  email_address: EMAIL,
  email: EMAIL,
  full_name: "Local User",
  name: "Local User",
  display_name: "Local User",
  has_password: true,
  has_completed_onboarding: true,
  preferred_language: "en-US",
  has_claude_pro: true,
  settings: { theme: "system", language: "en-US" },
};

const ORG = {
  uuid: ORG_UUID,
  id: ORG_UUID,
  name: "Local",
  role: "admin",
  organization_type: "personal",
  billing_type: "self_serve",
  capabilities: ["chat", "claude_pro_plan", "api", "computer_use", "claude_for_chrome"],
  rate_limit_tier: "default_claude_pro",
  settings: {},
};

const PROFILE = {
  ...ACCOUNT,
  account: ACCOUNT,
  organization: ORG,
  organizations: [ORG],
  memberships: [{ organization: ORG, role: "admin", joined_at: "2024-01-01T00:00:00Z" }],
  active_organization_uuid: ORG_UUID,
};

const BOOTSTRAP = {
  ...PROFILE,
  account_uuid: USER_UUID,
  statsig: {
    user: { userID: USER_UUID, custom: { organization_uuid: ORG_UUID } },
    values: { feature_gates: {}, dynamic_configs: {}, layer_configs: {} },
  },
  flags: {},
  features: [],
  active_flags: {},
  active_subscription: {
    plan: "claude_pro",
    status: "active",
    type: "claude_pro",
    billing_period: "monthly",
    current_period_start: "2024-01-01T00:00:00Z",
    current_period_end: "2099-12-31T23:59:59Z",
  },
  chat_enabled: true,
};

function optionsResponse() {
  return {
    mode: "",
    cfcBase: LOCAL_BASE,
    anthropicBaseUrl: "",
    apiBaseIncludes: ["https://api.anthropic.com/v1/"],
    proxyIncludes: PROXY_INCLUDES,
    discardIncludes: [
      "cdn.segment.com",
      "api.segment.io",
      "events.statsigapi.net",
      "api.honeycomb.io",
      "prodregistryv2.org",
      "*ingest.us.sentry.io",
      "browser-intake-us5-datadoghq.com",
    ],
    modelAlias: {},
    ui: {},
    uiNodes: [],
  };
}

function authResponse(path) {
  if (path.includes("/oauth/token")) return tokenResponse();
  if (path.includes("/oauth/profile") || path.includes("/oauth/account")) return PROFILE;
  if (path.includes("/bootstrap")) return BOOTSTRAP;
  if (path.includes("/oauth/organizations")) return [ORG];
  if (path.includes("/chat_conversations")) return { conversations: [], limit: 0, has_more: false, cursor: null };
  if (path.includes("/domain_info")) return { domain: "local", allowed: true };
  if (path.includes("/url_hash_check")) return { allowed: true };
  if (path.includes("/licenses/verify")) return { valid: true, license: "local", tier: "pro", expires: "2099-12-31" };
  if (path.includes("/mcp/v2/bootstrap")) return { servers: [], tools: [], enabled: false };
  if (path.includes("/usage")) return { usage: {}, limit: null };
  if (path.includes("/entitlements")) return { entitlements: [] };
  if (path.includes("/flags") || path.includes("/features/")) return {};
  return {};
}

function authorizePage(url) {
  const qs = url.searchParams.toString();
  return htmlResponse(`<!doctype html>
<html><head><meta charset="utf-8"><title>CFC Sign In</title></head>
<body style="font-family:system-ui;background:#f9f8f3;color:#1d1b16;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
<main style="background:white;border:1px solid #e5e2d9;border-radius:24px;padding:32px;max-width:420px;text-align:center">
<h1 style="font:400 24px Georgia;margin:0 0 8px">Claude in Chrome</h1>
<p style="color:#6b6651;font-size:13px;line-height:1.5">Local CFC replacement. No Anthropic credentials are requested.</p>
<button id="go" style="background:#c45f3d;color:white;border:0;border-radius:12px;padding:12px 22px;font-weight:700;cursor:pointer">Enter</button>
<p id="msg" style="font-size:12px;color:#8b856c;margin-top:14px"></p>
</main>
<script>
document.getElementById("go").onclick = () => {
  document.getElementById("msg").textContent = "Continuing...";
  location.href = "/oauth/redirect${qs ? "?" + qs.replace(/"/g, "%22") : ""}";
};
setTimeout(() => document.getElementById("go").click(), 400);
</script></body></html>`);
}

function redirectPage(url) {
  const qp = url.searchParams.toString();
  return htmlResponse(`<!doctype html>
<html><head><meta charset="utf-8"><title>Authenticating</title></head>
<body style="font-family:system-ui;background:#f9f8f3;color:#1d1b16;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
<main style="background:white;border:1px solid #e5e2d9;border-radius:24px;padding:32px;max-width:460px;text-align:center">
<h1 style="font:400 22px Georgia;margin:0 0 8px">Signed in</h1>
<p id="msg" style="color:#6b6651;font-size:13px">Finishing local CFC auth...</p>
</main>
<script>
(async () => {
  const msg = document.getElementById("msg");
  const params = new URLSearchParams(${JSON.stringify(qp)});
  let redirectUri = params.get("redirect_uri") || "";
  const state = params.get("state") || "";
  let eid = ${JSON.stringify(EXTENSION_ID)};
  if (redirectUri.startsWith("chrome-extension://")) {
    try { eid = new URL(redirectUri).host; } catch (e) {}
  }
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  const code = Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");
  let finalUri = redirectUri;
  if (finalUri) {
    try {
      const u = new URL(finalUri);
      u.searchParams.set("code", code);
      if (state) u.searchParams.set("state", state);
      finalUri = u.toString();
    } catch (e) {
      finalUri = redirectUri + (redirectUri.includes("?") ? "&" : "?") + "code=" + code;
    }
  }
  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage(eid, {type: "oauth_redirect", redirect_uri: finalUri}, (rv) => {
      if (chrome.runtime.lastError) {
        msg.textContent = "Extension message failed: " + chrome.runtime.lastError.message;
        msg.style.color = "#b04a3d";
        return;
      }
      msg.textContent = "Done. You can close this tab.";
      msg.style.color = "#2d6a4f";
      setTimeout(() => { try { window.close(); } catch (e) {} }, 800);
    });
  } else if (finalUri) {
    location.href = finalUri;
  } else {
    msg.textContent = "Auth complete.";
    msg.style.color = "#2d6a4f";
  }
})();
</script></body></html>`);
}

function backendSettingsPage() {
  return htmlResponse(`<!doctype html>
<html><head><meta charset="utf-8"><title>Backend Settings</title></head>
<body style="font-family:system-ui;background:#f9f8f3;color:#1d1b16;margin:0;padding:32px">
<main style="max-width:620px;margin:auto;background:white;border:1px solid #e5e2d9;border-radius:24px;padding:28px">
<h1 style="font:400 26px Georgia;margin:0 0 8px">Backend Settings</h1>
<p style="color:#6b6651">Safe replacement for Cocodem remote config. The local server is the source of truth.</p>
<p><a href="${LOCAL_BASE}backend_settings" style="color:#c45f3d;font-weight:700">Open local backend settings</a></p>
<pre style="background:#1d1b16;color:#eee;border-radius:10px;padding:12px;white-space:pre-wrap">${LOCAL_BASE}</pre>
</main></body></html>`);
}

function isAuthPath(path) {
  return path.startsWith("/https://") ||
    path.startsWith("/http://") ||
    ["/oauth/", "/bootstrap", "/domain_info", "/url_hash_check", "/chat_conversations", "/organizations", "/licenses/", "/mcp/v2/", "/usage", "/entitlements", "/flags"].some(x => path.includes(x));
}

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const path = url.pathname;

    if (request.method === "OPTIONS") return emptyResponse(200);
    if (DISCARD.some(x => request.url.includes(x))) return emptyResponse(204);
    if (path === "/" || path === "") {
      return htmlResponse(`<!doctype html><title>CFC Worker</title><body><h1>CFC Worker</h1><p>Remote: ${REMOTE_BASE}</p><p>Local: ${LOCAL_BASE}</p><p><a href="/api/options">api/options</a> <a href="/backend_settings">backend_settings</a></p></body>`);
    }
    if (path.startsWith("/api/options")) return jsonResponse(optionsResponse());
    if (path.startsWith("/backend_settings")) return backendSettingsPage();
    if (path.includes("/oauth/authorize")) return authorizePage(url);
    if (path.includes("/oauth/redirect")) return redirectPage(url);
    if (isAuthPath(path)) return jsonResponse(authResponse(path));
    return jsonResponse({ ok: true, path });
  },
};
